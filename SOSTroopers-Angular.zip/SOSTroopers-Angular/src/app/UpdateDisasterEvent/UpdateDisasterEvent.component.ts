import { Component, OnInit, Inject } from '@angular/core';
import { ActivatedRoute, Router} from '@angular/router';
import { GlobalService} from '../services/global/global.service';
import { CreateDisasterService } from '../services/createdisaster/createdisaster.service';
import { GetDisasterEventsService } from '../services/getdisasterevents/getdisasterevents.service';
import { FormGroup, Validators, FormControl, FormBuilder } from '@angular/forms';
import {LOCAL_STORAGE, WebStorageService} from 'angular-webstorage-service';
declare var jquery: any;
declare var $: any;
 declare function myMethod():any;

@Component({
  selector: 'app-update-disaster-event',
  templateUrl: './UpdateDisasterEvent.component.html',
  styleUrls: ['./UpdateDisasterEvent.component.css']
})
export class UpdateDisasterEventComponent implements OnInit {
  availShelters:any;
  disasterEvent:any;

  state:string="";
  country:string="";
  AreaAffected:string="";
  message:string="";
  errorpng:boolean=false;
  angForm: FormGroup;
  shelter:boolean=true;
  medical:boolean=true;
  serviceProvide:any=[];
  disaster:any={};
  disasters:any=[];
  loader:boolean=false;
  // sub;
  constructor(@Inject(LOCAL_STORAGE) private storage: WebStorageService,private globalService: GlobalService,private activatedRoute: ActivatedRoute,private router:Router,private createDisasterService: CreateDisasterService,private getDisasterEventsService: GetDisasterEventsService) {
   this.disasterEvent=this.storage.get("disasterEvent");
   this.disaster=this.storage.get("disaster");
   console.log("this disaster::"+this.disasterEvent);
   
    if(this.disasterEvent==0 || this.disasterEvent==null){
      this.disasterEvent=0;
      
    }else{
      this.showDisaster();
    }
    this.getAllDisasterEvents();
  
  }

   getAllDisasterEvents(){
    $(".overlay").show();
   this.errorpng=false;
    console.log("here calling servie.......")
    this.getDisasterEventsService.GetDisasterEvents().subscribe((data: any) => {

      this.disasters = data["Events"];
      $(".overlay").hide();
        //this.message="More than one person found.. Please enter unique details.."
          this.errorpng=false;
        
      
      console.log(data);
    }, error => {
     // error path);
    this.disasters=[];
      this.errorpng=true;
       $(".overlay").hide();
      this.message="Something went wrong.."
      $("#messageModal").modal();
      console.log(error);
    }
    );
  }
 
   updateDisaster() {
    
    //this.disaster["$class"] = "org.disaster.model.Disaster_Event";
    //this.disaster["Event_Id"] = this.globalService.getId();
    this.disaster["loc"] =  
    {
      "$class": "org.disaster.model.DisLocation",
      "State": this.state,
      "Country": this.country
    } ;
    var areas=[];
    for(let i=0;i<this.AreaAffected.split(",").length;i++){
      areas.push(this.AreaAffected.split(",")[i].trim());

    }
  this.serviceProvide=[];
    this.disaster["AreaAffected"]=areas;
     if (this.shelter) {
      this.serviceProvide.push('Shelter');
    }
    if (this.medical) {
      this.serviceProvide.push('Medical');
    }
    this.disaster["Types_Of_Help_Needed"]=this.serviceProvide;
    console.log("here calling servie.......")
     $(".overlay").show();
    this.createDisasterService.updateDisaster(this.disaster).subscribe((data: any) => {

       $(".overlay").hide();
       this.message="Updated"+ this.disaster.EventName +"event successfully..!";
      this.errorpng=false;
      $("#messageModal").modal();
      console.log(data);
    }, error => {
       $(".overlay").hide();
       this.message="Something went wrong..!!";
      this.errorpng=true;
      $("#messageModal").modal();
      console.log(error);
    }
    );
  }

  ngOnInit() {
    
    console.log("calling init")

    // myMethod()
    this.angForm = new FormGroup({
      name: new FormControl('', Validators.compose([
        Validators.required,
        Validators.maxLength(25),
        Validators.pattern('^[A-Za-z0-9 ]+$')
      ])),

      typeofdisaster: new FormControl('', Validators.compose([
        Validators.required
      ])),


      country: new FormControl('', Validators.compose([
        Validators.required
      ])),

      state: new FormControl('', Validators.compose([
        Validators.required
      ])),

      // dod: new FormControl('', Validators.compose([
      //   Validators.required
      // ])),

      //  edod: new FormControl(''),
      description: new FormControl('', Validators.compose([
        Validators.required
      ])),

      areasaffected: new FormControl('', Validators.compose([
        Validators.required,
        Validators.pattern('^[A-Za-z0-9 ,]+$')
        
      ])),
      shelter: new FormControl(''),
      medical: new FormControl('')

    })
    

    // this.sub = this.activatedRoute.queryParams
    //                 .subscribe(params => { 
    //                  this.disasterEvent = +params['disasterEvent']||0;
    //                  console.log('Query params ',this.disasterEvent) });
   }


  

   showDisaster(){
    
       this.AreaAffected="";
       if(this.disaster.AreaAffected.length!=0){
         this.AreaAffected=this.disaster.AreaAffected[0];
       }
    for(let i=1;i<this.disaster.AreaAffected.length;i++){
      this.AreaAffected=this.AreaAffected+", "+this.disaster.AreaAffected[i];

    }

    this.country=this.disaster.loc.Country;
    this.state=this.disaster.loc.State;

    this.shelter=false;
    this.medical=false;
    
    for(let i=0;i<this.disaster.Types_Of_Help_Needed.length;i++){
     
          if(this.disaster.Types_Of_Help_Needed[i].toLocaleLowerCase()=="Shelter".toLocaleLowerCase()){
           
            this.shelter=true;
          }
          else if(this.disaster.Types_Of_Help_Needed[i].toLocaleLowerCase()=="Medical".toLocaleLowerCase()){
            
            this.medical=true;
          }
    }

     setTimeout(() => {
         myMethod();
    }, 3)

    
   }
   onItemChange(value){
  
   console.log("calling here itemChange function: "+ value);
   this.disasterEvent=parseInt(value)+1;
   
    this.storage.set("disasterEvent", this.disasterEvent);
      this.storage.set("disaster", this.disasters[value]);
   this.disaster=this.disasters[value];
    console.log("disaster Id in search onItemChange: "+this.disasterEvent);
   this.showDisaster();

  
   
    
    //  this.openModal(true);
   //this.router.navigate(['./home'], { queryParams: { disasterEvent: this.disasterEvent },relativeTo: this.activatedRoute });
 
 }


 account_validation_messages = {
    'name': [
      { type: 'required', message: 'Disaster Name is required' },
      { type: 'maxlength', message: 'Name cannot be more than 25 characters long' },
      { type: 'pattern', message: 'Name must contain only letters and numbers' }
    ],

    'typeofdisaster': [
      { type: 'required', message: 'Must select disaster type' }
     
    ],

    'country': [
      { type: 'required', message: 'Country is required' }
    
      
    ],

    'description': [
      { type: 'required', message: 'Description is required' }
    
      
    ],


    'state': [
      { type: 'required', message: 'State is required' }
    ],

    'areasaffected': [
      { type: 'required', message: 'Areas affected is required' },
      { type: 'pattern', message: 'Areas affected must contain characters (A-Za-z0-9 ,) only' }
    ]

  }

}
