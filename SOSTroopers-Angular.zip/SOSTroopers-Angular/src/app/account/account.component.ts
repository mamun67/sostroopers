import { Component, OnInit, Inject } from '@angular/core';
import {AppComponent} from '../app.component'
import { WeatherapiService } from  '../services/weatherapi/weatherapi.service';
import { GlobalService } from  '../services/global/global.service';
import { ActivatedRoute, Router} from '@angular/router';
import { GetDisasterEventsService} from '../services/getdisasterevents/getdisasterevents.service';
import { GetShelterByDisasterService} from '../services/getShelterByDisaster/getShelterByDisaster.service';
import {LOCAL_STORAGE, WebStorageService} from 'angular-webstorage-service';
declare var jquery: any;
declare var $: any;
declare function mapShow(locations):any;

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})
export class AccountComponent implements OnInit {
  
  lat: number;
  lng: number;
  disasterEvent:any;
  disaster:any={};
  disasters:any=[];
  errorpng:boolean=false;
  loader:boolean=false;
  message:string="";
  availShelters:any=[];
  login:boolean=false;
  user:any={};
  locations=[];
  // disasterIndex=-1;
// currentWeather:any;
// currentDayShift:any;
//  changeWeather(currentWeather,currentDayShift){
//         this.changeWeather=currentWeather;
//         this.currentDayShift=currentDayShift;
//     }
constructor(@Inject(LOCAL_STORAGE) private storage: WebStorageService,@Inject(GetShelterByDisasterService) private getShelterByDisaster:GetShelterByDisasterService,@Inject(GetDisasterEventsService) private getDisasterEvents:GetDisasterEventsService,@Inject(GlobalService) private globalService: GlobalService,private activatedRoute: ActivatedRoute,private router:Router){
 
  this.login=this.storage.get("login");
        this.user=this.storage.get("user");
        console.log("user is");
        console.log(this.user);
        if($.isEmptyObject(this.user)){
          this.user={
            "Role":""
          }
        }
   this.disasterEvent=this.storage.get("disasterEvent");
   this.disaster=this.storage.get("disaster");
   if($.isEmptyObject(this.disaster)){
          this.disaster={
            "Other":""
          }
          this.disasterEvent=0;
          //  this.disasterIndex=this.disasterEvent-1;
        }
        this.getAllDisasters();
        
   if(this.disasterEvent!=0){
    //  this.disasterIndex=this.disasterEvent-1;
      this.getAllShelters();
   }
 console.log("disaster Id in home constructor: "+this.disasterEvent);
}
// sub;

ngOnInit() {


 console.log("disaster Id in home ngOnit: "+this.disasterEvent);
 if (window.navigator && window.navigator.geolocation) {
        window.navigator.geolocation.getCurrentPosition(
            position => {
                this.lat = position.coords.latitude;
                this.lng = position.coords.longitude;
               var  loc=[];
          loc.push('Your Location');
          loc.push(this.lat);
          loc.push(this.lng);
          loc.push(1);
          // loc.push("");
          this.locations.push(loc);
                mapShow(this.locations);
                    console.log(position)
            },
            error => {
                switch (error.code) {
                    case 1:
                        console.log('Permission Denied');
                        break;
                    case 2:
                        console.log('Position Unavailable');
                        break;
                    case 3:
                        console.log('Timeout');
                        break;
                }
            }
        );
    };
     console.log("calling init")
    // this.sub = this.activatedRoute.queryParams
    //                 .subscribe(params => { 
    //                  this.disasterEvent = +params['disasterEvent']||0;
    //                  console.log('Query in account params ',this.disasterEvent);
    //                  console.log('Query in account real params ',params['disasterEvent']);
    //                 });

}

 getAllDisasters() {
   $(".overlay").show();
   this.errorpng=false;
    console.log("here calling servie.......")
    this.getDisasterEvents.GetDisasterEvents().subscribe((data: any) => {

      this.disasters = data["Events"];
      $(".overlay").hide();
        //this.message="More than one person found.. Please enter unique details.."
          this.errorpng=false;
        
      
      console.log(data);
    }, error => {
     // error path);
    this.disasters=[];
      this.errorpng=true;
       $(".overlay").hide();
      this.message="Something went wrong.."
      console.log(error);
    }
    );
  }
  disasterChange(){
      this.disasterEvent=0;
      var user={}
       this.globalService.setDisasterId(this.disasterEvent);
   this.globalService.setDisaster(user);
   this.disaster=user;
  }

  getAllShelters() {
   this.errorpng=false;
    $(".overlay").show();
    this.locations=[];
    console.log("here calling servie.......")
    this.getShelterByDisaster.getShelterByDisaster(this.disaster.EventName).subscribe((data: any) => {
      this.errorpng=false;
      this.availShelters = data["Events"];
      var loc=[];
      for(let i=0;i<this.availShelters.length;i++){
          loc=[];
          loc.push(this.availShelters[i].Shelter_Id);
          loc.push(this.availShelters[i].location.latitude);
          loc.push(this.availShelters[i].location.longititude);
          loc.push(i+2);
          // loc.push("http://localhost:4200/showShelter?shelterName="+this.availShelters[i].Shelter_Id);
          this.locations.push(loc);
      }
      // ['Cronulla Beach', -34.028249, 151.157507, 3],
      console.log("locations here is:");
      console.log(this.locations);
      mapShow(this.locations);
      $(".overlay").hide();
        //this.message="More than one person found.. Please enter unique details.."
          
        
      
      console.log(data);
    }, error => {
     // error path);
       $(".overlay").hide();
       this.availShelters=[];
      this.errorpng=true;
      this.message="Something went wrong.."
      console.log(error);
    }
    );
  }


onItemChange(value){
  
   console.log("calling here itemChange function: "+ value);
   this.disasterEvent=parseInt(value)+1;
   this.storage.set("disasterEvent",this.disasterEvent);
   this.storage.set("disaster",this.disasters[value]);
   this.disaster=this.disasters[value];
    this.getAllShelters();
//  console.log("disaster Id in home itemChange: "+this.globalService.getDisasterId());
  // this.router.navigate(['./'], { queryParams: { disasterEvent: this.disasterEvent },relativeTo: this.activatedRoute });
 
 }
    

  }

  