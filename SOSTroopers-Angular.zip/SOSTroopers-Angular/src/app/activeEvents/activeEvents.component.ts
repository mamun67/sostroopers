import { Component, OnInit, Inject } from '@angular/core';
import { ActivatedRoute, Router} from '@angular/router';
import { FormGroup, Validators, FormControl, FormBuilder } from '@angular/forms';
import { GetDisasterEventsService} from '../services/getdisasterevents/getdisasterevents.service';
import { GlobalService} from '../services/global/global.service';
import { GetAllNGOsService } from '../services/getallngos/getallngos.service';
import { CreateShelterService } from '../services/createshelter/createshelter.service';
import { RequestsService } from '../services/requests/requests.service';
import {LOCAL_STORAGE, WebStorageService} from 'angular-webstorage-service';
declare var jquery: any;
declare var $: any; 

declare function showTabsFunc():any;

@Component({
  selector: 'app-active-events',
  templateUrl: './activeEvents.component.html',
  styleUrls: ['./activeEvents.component.css']
})
export class ActiveEventsComponent implements OnInit {
  allDisasters:any;
  error:any;
  message:string="";
  errorpng:boolean;
  disasters:any={};
  helpNeeded:string="";
  showDiv:string="";
  availShelters:any=[];
    angForm: FormGroup;
    resourceForm: FormGroup;
    resourcesForm: FormGroup;
    showResource:boolean=false;
     shelterInfo=false;
    
  constructor(@Inject(LOCAL_STORAGE) private storage: WebStorageService,private requestsService:RequestsService,private createShelterService:CreateShelterService,private getAllNGOsService:GetAllNGOsService,private globalService: GlobalService,private activatedRoute: ActivatedRoute,private router:Router,private getDisasterEvents:GetDisasterEventsService) {
   this.allDisasters=[];
   this.shelterInfo=false;
    this.availShelters=[];
    this.getActiveEvents();
  // this.getDisastersByStatus();

  //this.getSheltersByNGOAndDisaster();
//     this.allDisasters=[
//   {
//     "$class": "org.disaster.model.Disaster_Event",
//     "Name":"Name Of Disaster",
//     "Event_Id": "0259",
//     "location": [{
//       "$class": "org.disaster.model.DisLocation",
//       "State": "Duis",
//       "Country": "Anim labore"
//     } ],
//     "Type_Of_Disaster": "Flood",
//     "AreaAffected": [
//       "Chennai",
//       "Sipcot"
//     ],
//     "Types_Of_Help_Needed": [
//       "Shelter",
//       "Volunteer"
//     ],
//     "status": "Active",
//     "siteAdmin": "resource:org.disaster.model.Site_Admin#6769",
//     "ngos": [
//        {
//     "$class": "org.disaster.model.NGO",
//     "GlobalId": "string",
//     "Name": "string",
//     "Admin": "string",
//     "Address": "string",
//     "NGO_Email": "string",
//     "Contact": "string",
//     "Branches": "string",
//     "ServicesProvide": [],
//     "event": []
//   },{
//     "$class": "org.disaster.model.NGO",
//     "GlobalId": "string",
//     "Name": "string",
//     "Admin": "string",
//     "Address": "string",
//     "NGO_Email": "string",
//     "Contact": "string",
//     "Branches": "string",
//     "ServicesProvide": [],
//     "event": []
//   },{
//     "$class": "org.disaster.model.NGO",
//     "GlobalId": "string",
//     "Name": "string",
//     "Admin": "string",
//     "Address": "string",
//     "NGO_Email": "string",
//     "Contact": "string",
//     "Branches": "string",
//     "ServicesProvide": [],
//     "event": []
//   },{
//     "$class": "org.disaster.model.NGO",
//     "GlobalId": "string",
//     "Name": "string",
//     "Admin": "string",
//     "Address": "string",
//     "NGO_Email": "string",
//     "Contact": "string",
//     "Branches": "string",
//     "ServicesProvide": [],
//     "event": []
//   }
//     ]
//   },{
//     "$class": "org.disaster.model.Disaster_Event",
//     "Event_Id": "0259",
//     "Name":"Name Of Disaster",
//     "location": [{
//       "$class": "org.disaster.model.DisLocation",
//       "State": "Duis",
//       "Country": "Anim labore"
//     } ],
//     "Type_Of_Disaster": "Flood",
//     "AreaAffected": [
//       "Chennai",
//       "Sipcot"
//     ],
//     "Types_Of_Help_Needed": [
//       "Shelter",
//       "Volunteer"
//     ],
//     "status": "Active",
//     "siteAdmin": "resource:org.disaster.model.Site_Admin#6769",
//     "ngos": [
//        {
//     "$class": "org.disaster.model.NGO",
//     "GlobalId": "string",
//     "Name": "string",
//     "Admin": "string",
//     "Address": "string",
//     "NGO_Email": "string",
//     "Contact": "string",
//     "Branches": "string",
//     "ServicesProvide": [],
//     "event": []
//   },{
//     "$class": "org.disaster.model.NGO",
//     "GlobalId": "string",
//     "Name": "string",
//     "Admin": "string",
//     "Address": "string",
//     "NGO_Email": "string",
//     "Contact": "string",
//     "Branches": "string",
//     "ServicesProvide": [],
//     "event": []
//   },{
//     "$class": "org.disaster.model.NGO",
//     "GlobalId": "string",
//     "Name": "string",
//     "Admin": "string",
//     "Address": "string",
//     "NGO_Email": "string",
//     "Contact": "string",
//     "Branches": "string",
//     "ServicesProvide": [],
//     "event": []
//   },{
//     "$class": "org.disaster.model.NGO",
//     "GlobalId": "string",
//     "Name": "string",
//     "Admin": "string",
//     "Address": "string",
//     "NGO_Email": "string",
//     "Contact": "string",
//     "Branches": "string",
//     "ServicesProvide": [],
//     "event": []
//   }
//     ]
//   },{
//     "$class": "org.disaster.model.Disaster_Event",
//     "Event_Id": "0259",
//     "Name":"Name Of Disaster",
//     "location": [{
//       "$class": "org.disaster.model.DisLocation",
//       "State": "Duis",
//       "Country": "Anim labore"
//     } ],
//     "Type_Of_Disaster": "Flood",
//     "AreaAffected": [
//       "Chennai",
//       "Sipcot"
//     ],
//     "Types_Of_Help_Needed": [
//       "Shelter",
//       "Volunteer"
//     ],
//     "status": "Active",
//     "siteAdmin": "resource:org.disaster.model.Site_Admin#6769",
//     "ngos": [
//        {
//     "$class": "org.disaster.model.NGO",
//     "GlobalId": "string",
//     "Name": "string",
//     "Admin": "string",
//     "Address": "string",
//     "NGO_Email": "string",
//     "Contact": "string",
//     "Branches": "string",
//     "ServicesProvide": [],
//     "event": []
//   },{
//     "$class": "org.disaster.model.NGO",
//     "GlobalId": "string",
//     "Name": "string",
//     "Admin": "string",
//     "Address": "string",
//     "NGO_Email": "string",
//     "Contact": "string",
//     "Branches": "string",
//     "ServicesProvide": [],
//     "event": []
//   },{
//     "$class": "org.disaster.model.NGO",
//     "GlobalId": "string",
//     "Name": "string",
//     "Admin": "string",
//     "Address": "string",
//     "NGO_Email": "string",
//     "Contact": "string",
//     "Branches": "string",
//     "ServicesProvide": [],
//     "event": []
//   },{
//     "$class": "org.disaster.model.NGO",
//     "GlobalId": "string",
//     "Name": "string",
//     "Admin": "string",
//     "Address": "string",
//     "NGO_Email": "string",
//     "Contact": "string",
//     "Branches": "string",
//     "ServicesProvide": [],
//     "event": []
//   }
//     ]
//   }
// ]


this.availShelters=[
  {
    "$class": "org.disaster.model.Shelter",
    "Shelter_Id": "Shelter1",
    "Total_Capacity": 300,
    "location": {
      "$class": "org.disaster.model.Location",
      "latitude": "21",
      "longitude": "25"
    },
    "CurrentPeople": 0,
    "Contact": "+0342-9087659",
    "No_Of_doctors": 12,
    "No_Of_Volunteer": 60,
    "available_Equipment": [
      {
        "$class": "org.disaster.model.Available_Equipment",
        "Equipment_Name": "xyz",
        "Count": "10"
      },
      {
        "$class": "org.disaster.model.Available_Equipment",
        "Equipment_Name": "abc",
        "Count": "12"
      }
    ],
    "available_Amenities": [
      {
        "$class": "org.disaster.model.Available_Amenities",
        "Amenities_Name": "cde",
        "Count": "20"
      }
    ],
    "resident": [
      {
        "$class": "org.disaster.model.ResidentUpdate",
        "Name": "Suparna Roy",
        "Father_Name": "Swapan Kumar Roy",
        "DOB": "22 Mar 1993",
        "Address": "Burdwan, Kolkata",
        "Resident_Email": "suparnaroy@gmail.com",
        "Contact": "7797549390",
        "Biometric": "mIyo=",
        "BloodGroup": "A+",
        "shelter": []
      }
    ],
    "ngo": "resource:org.disaster.model.NGO#8017"
  },
  {
    "$class": "org.disaster.model.Shelter",
    "Shelter_Id": "Shelter2",
    "Total_Capacity": 300,
    "location": {
      "$class": "org.disaster.model.Location",
      "latitude": "21",
      "longitude": "25"
    },
    "CurrentPeople": 0,
    "Contact": "+0342-9087659",
    "No_Of_doctors": 12,
    "No_Of_Volunteer": 60,
    "available_Equipment": [
      {
        "$class": "org.disaster.model.Available_Equipment",
        "Equipment_Name": "xyz",
        "Count": "10"
      },
      {
        "$class": "org.disaster.model.Available_Equipment",
        "Equipment_Name": "abc",
        "Count": "12"
      }
    ],
    "available_Amenities": [
      {
        "$class": "org.disaster.model.Available_Amenities",
        "Amenities_Name": "cde",
        "Count": "20"
      }
    ],
    "resident": [
  {
    "$class": "org.disaster.model.Resident",
    "Name": "SK arfin",
    "Father_Name": "asasas",
    "DOB": "2018-08-05",
    "Address": "KOL",
    "Resident_Email": "sk.arfin@capgemini.com",
    "Contact": "9090909090",
    "Biometric": "D160A686FEAC8FFD95070E185A8735F14C5B9D7E",
    "BloodGroup": "a-",
    "shelter": []
  },
  {
    "$class": "org.disaster.model.Resident",
    "Name": "Spanadana Bola",
    "Father_Name": "sdadas",
    "DOB": "2017-07-05",
    "Address": "sasAS",
    "Resident_Email": "spanadana.bola@capgemini.com",
    "Contact": "9492371909",
    "Biometric": "8FDA5EECAC5CF9444548269ED33E7AC6D3A4E199",
    "BloodGroup": "b+",
    "shelter": []
  },
  {
    "$class": "org.disaster.model.Resident",
    "Name": "Suparna Roy",
    "Father_Name": "Swapan Kumar Roy",
    "DOB": "22 Mar 1993",
    "Address": "Burdwan, Kolkata",
    "Resident_Email": "suparnaroy@gmail.com",
    "Contact": "7797549390",
    "Biometric": "mIyo=",
    "BloodGroup": "A+",
    "shelter": [
      {
        "$class": "org.disaster.model.ShelterInfo",
        "Status": "Moved",
        "shelterId": "resource:org.disaster.model.Shelter#Shelter1"
      }
    ]
  }
],
    "ngo": "resource:org.disaster.model.NGO#8016"
  }
]

  }

   getActiveEvents(){
     this.user=this.storage.get("user");
     this.allDisasters=[];
     for(let i=0;i<this.user.Active_event.length;i++){
       console.log(this.user.Active_event[i]);
       console.log("disaster here is:"+this.user.Active_event[i].disasater);
          this.getAllDisasterEvents(this.user.Active_event[i].disasater.split("#")[1]);
     }

  }

   getAllDisasterEvents(id){
    $(".overlay").show();
   
    this.getDisasterEvents.getDisasterById(id).subscribe((data: any) => {
       $(".overlay").hide();
      this.allDisasters.push(data);
      
        this.errorpng=false;
        
      console.log(data);
    }, error => {
      $(".overlay").hide();
     
      this.errorpng=true;
      
      this.message="Something went wrong.."
      $("#showMessage").modal();
      console.log(error);
    }
    );
  }

  ngOnInit() {
    console.log("calling init")
   this.disasters={
    "$class": "org.disaster.model.Disaster_Event",
    "Name":"",
    "Event_Id": "",
    "location": [{
      "$class": "org.disaster.model.DisLocation",
      "State": "",
      "Country": ""
    } ],
    "Type_Of_Disaster": "",
    "AreaAffected": [
     
    ],
    "Types_Of_Help_Needed": [
     
    ],
    "status": ""
  
   }

   this.shelter= {
    "$class": "org.disaster.model.Shelter",
    "Shelter_Id": "Shelter1",
    "Total_Capacity": 300,
    "location": {
      "$class": "org.disaster.model.Location",
      "latitude": "21",
      "longitude": "25"
    },
    "CurrentPeople": 0,
    "Contact": "+0342-9087659",
    "No_Of_doctors": 12,
    "No_Of_Volunteer": 60,
    "available_Amenities": [
    ],
    "resident": [
    ],
    "ngo": "resource:org.disaster.model.NGO#8017"
  }

     this.angForm = new FormGroup({
      capacity: new FormControl('', Validators.compose([
        Validators.required,  
        Validators.pattern('^[0-9]+$')
      ])),

       doctors: new FormControl('', Validators.compose([
        Validators.required,  
        Validators.pattern('^[0-9]+$')
      ])),
      volunteers: new FormControl('', Validators.compose([
        Validators.required,  
        Validators.pattern('^[0-9]+$')
      ])),

       status: new FormControl(''),
  
    })

    this.resourceForm = new FormGroup({
      amenitiesName: new FormControl('', Validators.compose([
        Validators.required,  
        Validators.pattern('^[A-Za-z ]+$')
      ])),

       amenitiesCount: new FormControl('', Validators.compose([
        Validators.required,  
        Validators.pattern('^[0-9]+$')
      ])),
      
    })

     this.resourcesForm = new FormGroup({
      resourceName: new FormControl('', Validators.compose([
        Validators.required,  
        Validators.pattern('^[A-Za-z ]+$')
      ])),

       resourceCount: new FormControl('', Validators.compose([
        Validators.required,  
        Validators.pattern('^[0-9]+$')
      ])),
      
    })
  }

  account_validation_messages = {
    'capacity': [
      { type: 'required', message: 'Total Capacity is required' },
      
      { type: 'pattern', message: 'Total Capacity must contain only numbers' }
    ],

     'doctors': [
      { type: 'required', message: 'No of doctors is required' },
      
      { type: 'pattern', message: 'No of doctors must contain only numbers' }
    ],

    'volunteers': [
      { type: 'required', message: 'No of volunteers is required' },
      
      { type: 'pattern', message: 'No of volunteers must contain only numbers' }
    ],

    'amenitiesName': [
      { type: 'required', message: 'Resource name is required' },
      
      { type: 'pattern', message: 'Resource name must contain only letters' }
    ],

    'amenitiesCount': [
      { type: 'required', message: 'Count is required' },
      
      { type: 'pattern', message: 'Count must contain only numbers' }
    ]
  }

     // this.sub = this.activatedRoute.queryParams
    //                 .subscribe(params => { 
    //                  this.disasterEvent = +params['disasterEvent']||0;
    //                  console.log('Query params ',this.disasterEvent) });
  

 openModal(value){
  this.showDiv=value;
 }

 isEdit:number=0;
 findCount(index){
   this.tempResourcesRequest[index].isEdit=false;
   this.isEdit=0;
   for(var i=0; i<this.tempResourcesRequest.length;i++){
     if(this.tempResourcesRequest[i].isEdit==false){
       this.isEdit=this.isEdit+1;
     }
    
   }
 }
  resourceCount:number=0;
  findResourceCount(index){
   this.tempResources[index].isEdit=false;
   this.resourceCount=0;
   for(var i=0; i<this.tempResources.length;i++){
     if(this.tempResources[i].isEdit==false){
       this.resourceCount=this.resourceCount+1;
     }
    
   }
   console.log("on save count: "+this.resourceCount);
 }

requestFail:boolean=false;
 raise(){

    var count=0;
    var failCount=0;
    $(".overlaymodal").show();
   for(let i=0;i<this.tempResourcesRequest.length;i++){
       var obj=  {
  "$class": "org.disaster.model.RaiseRequest",
  "request_Id": this.globalService.getId(),
  "Amenitiesname": this.tempResourcesRequest[i].Amenities_Name,
  "count": this.tempResourcesRequest[i].Count,
  "comments":[],
  "disaster_name":this.disasters.EventName,
  "shelter": this.newShelt.Shelter_Id,
  "date":new Date().toUTCString(),
  "request_status": "Open",
  "ngo": this.storage.get("user").NGO_Email
}
        
    console.log("here calling servie.......")
    this.requestsService.raiseRequest(obj).subscribe((data: any) => {

      count=count+1;
      if(count==this.tempResourcesRequest.length){
      $(".overlaymodal").hide();
      this.errorpng=false;
      $("#raiseRequest").modal('hide');
    }
        //this.message="More than one person found.. Please enter unique details.."
        //   this.errorpng=false;
        // this.loader=false;
      
      console.log(data);
    }, error => {
      
      this.error = error // error path);
       failCount=failCount+1;
      console.log(this.error);
    }
    );
    if(failCount!=0){
      $(".overlaymodal").hide();
      this.requestFail=true;
      break;
    }
    
    
   }

 }
 raiseRequest(shelt){
   this.newShelt=shelt;
   $("#raiseRequest").modal();
   this.tempResourcesRequest=[];
   this.tempResourcesRequest.push({
        "$class": "org.disaster.model.Available_Amenities",
        "Amenities_Name": "",
        "Count": "0",
        "isEdit":true
      });
 }

 deleteResource(index){
   this.tempResourcesRequest.splice(index,1);
 }
 shelter:any={};
 newShelt:any={};

 updateShelter(shelt,index){
   console.log("index of shelter: "+index)
   this.newShelt=this.availShelters[index];
   this.shelterInfo=true;
   this.showResource=false;
   console.log("newShelt: ");
   console.log(this.newShelt)
   this.showResources();
 }

 tempResources=[];
tempResourcesRequest=[];
 showResources(){
   this.tempResources=[];
   for(var i=0; i<this.newShelt.available_Amenities.length;i++){
     this.newShelt.available_Amenities[i]["isEdit"]=false;
     this.tempResources.push(this.newShelt.available_Amenities[i]);
   }
    this.resourceCount=this.tempResources.length;
   //this.showResource=true;
   console.log("on show resources:");
   console.log(this.tempResources);
 }

 addRow(){
     
     this.tempResourcesRequest.push({
        "$class": "org.disaster.model.Available_Amenities",
        "Amenities_Name": "",
        "Count": "0",
        "isEdit":true
      })

     
     
   
 }
loader:boolean=false;
  // getAllDisasterEvents(){
  //   this.loader=true;
  //   this.getDisasterEvents.GetDisasterEvents().subscribe((data: any) => {
  //     this.loader=false;
  //     this.allDisasters=data
     
  //       this.errorpng=false;
        
  //     console.log(data);
  //   }, error => {
  //     this.loader=false;
  //     this.errorpng=true;
  //     this.message="Something went wrong.."
  //     console.log(error);
  //   }
  //   );
  // }

 deleteRow(index){
   this.tempResources.splice(index,1);
 }
 showShelter(shelt){
   this.shelter=shelt;
   $("#showShelter").modal();
 }
 showtabs:boolean=false;
//  showloader:boolean=false;
   showModal(disaster){
     this.shelterInfo=false;
     this.availShelters=[];
      this.showtabs=true;
     this.helpNeeded="";
     this.disasters=disaster;
     if(this.disasters.Types_Of_Help_Needed.length!=0){
       this.helpNeeded=this.disasters.Types_Of_Help_Needed[0];
     }
     
     for(let index=1; index<this.disasters.Types_Of_Help_Needed.length; index++){
       this.helpNeeded=this.helpNeeded+","+this.disasters.Types_Of_Help_Needed[index];
     }
    
     this.getSheltersByNGOAndDisaster();

     //$("#showmodal").modal();
    //  this.showloader=true;
     setTimeout(() => {
      // this.showloader = false;
         $("#defaultOpen").click();
       // document.getElementById("defaultOpen").click();
    }, 3)
       //$("#onshow").click();
    //  console.log

   }

   addResource(){
     this.tempResources.push({
        "$class": "org.disaster.model.Available_Amenities",
        "Amenities_Name": "",
        "Amenities_Count": "0",
        "isEdit":true
      })

      console.log("new Shelt:");
      console.log(this.newShelt);
     
   }

   update(){
     $(".overlay").show();
     var resources=[];
     var resource={};
      for(var i=0; i<this.tempResources.length;i++){
        delete this.tempResources[i].isEdit;
   }
   this.newShelt.available_Amenities=this.tempResources;
   console.log("new Sheltdsdsdsd");
   console.log(this.newShelt.available_Amenities);
   this.newShelt["vacancy"]=this.newShelt.Total_Capacity-this.newShelt.CurrentPeople;
   
    this.createShelterService.updateShelter(this.newShelt).subscribe((data: any) => {
      $(".overlay").hide();
      // this.allDisasters=data
        this.shelterInfo=false;
        this.errorpng=false;
        
      console.log(data);
    }, error => {
      $(".overlay").hide();
      this.errorpng=true;
      this.message="Something went wrong.."
      $("#showMessage").modal();
      console.log(error);
    }
    );

   }

    getDisastersByStatus() {
      this.user=this.storage.get("user");
      this.allDisasters = [];
   $(".overlay").show();
   this.errorpng=false;
    console.log("here calling servie.......")
    this.getDisasterEvents.getDisasterByStatus(true).subscribe((data: any) => {
       $(".overlay").hide();
      for(let i=0;i<data.length;i++){
          for(let j=0;j<data[i].ngos.length;j++){
            if(data[i].ngos[j].ngo==this.user.NGO_Email){
              this.allDisasters.push(data[i]);
            }
          }
      }
      //$(".overlay").hide();
        //this.message="More than one person found.. Please enter unique details.."
          this.errorpng=false;
        
      
      console.log(data);
    }, error => {
     // error path);
    this.allDisasters=[];
      this.errorpng=true;
       $(".overlay").hide();
      this.message="Something went wrong.."
       $("#showMessage").modal();
      console.log(error);
    }
    );
  }

 user:any={};
 getSheltersByNGOAndDisaster() {
   this.errorpng=false;
   this.user=this.storage.get("user");
   this.availShelters=[];
  $(".overlay").show();
    console.log("here calling servie.......")
    this.getDisasterEvents.getShelterByDisasterAndNGO(this.disasters.EventName,this.user.NGO_Email).subscribe((data: any) => {

      this.availShelters = data;

      console.log("here shelter data is: ");
      console.log(this.availShelters);
         $(".overlay").hide();
        //this.message="More than one person found.. Please enter unique details.."
          this.errorpng=false;
        this.loader=false;
      
      console.log(data);
    }, error => {
      this.error = error // error path);
      this.availShelters =[];
      $(".overlay").hide();
      this.errorpng=true;
      this.message="Something went wrong.."
       $("#showMessage").modal();
      console.log(this.error);
    }
    );
  }
  backOff(disaster,index) {
   this.errorpng=false;
   var obj={
  "$class": "org.disaster.model.NgoBackOff",
  "ngo": "org.disaster.model.NGO#"+this.storage.get("user").NGO_Email,
  "disasterEventId": this.disasters["$class"]+"#"+this.disasters.EventName
}
   
    console.log("here calling servie.......")
    $(".overlay").show();
    this.getAllNGOsService.ngoBackoff(obj).subscribe((data: any) => {

      this.allDisasters.splice(index,1);//[index]
      $(".overlay").hide();
  //  if(this.allDisasters.length==0){
  //    this.message="No Active Disaster Events Found!!"
  //    this.errorpng=true;
  //  }
     
        //this.message="More than one person found.. Please enter unique details.."
          // this.errorpng=false;
        
      
      console.log(data);
    }, error => {
      this.error = error // error path);
      $(".overlay").hide();
      this.errorpng=true;
      this.message="Something went wrong.."
       $("#showMessage").modal();
      console.log(this.error);
    }
    );
  }


}
