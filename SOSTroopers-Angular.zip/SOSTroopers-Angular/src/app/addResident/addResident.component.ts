import { Component, OnInit, Inject } from '@angular/core';
import { ActivatedRoute, Router} from '@angular/router';
import { GlobalService} from '../services/global/global.service';
import { SearchpeopleService } from '../services/searchpeople/searchpeople.service';
import { UserRegisterService } from '../services/userregister/userregister.service';
import { FormGroup, Validators, FormControl, FormBuilder } from '@angular/forms';
// import {MatSelectModule,MatFormFieldModule,MatInputModule} from '@angular/material';
import { GetDisasterEventsService} from '../services/getdisasterevents/getdisasterevents.service';
import { AddShelterService} from '../services/addShelter/addShelter.service';
import {LOCAL_STORAGE, WebStorageService} from 'angular-webstorage-service';
declare var jquery: any;
declare var $: any; 

@Component({
  selector: 'app-add-resident',
  templateUrl: './addResident.component.html',
  styleUrls: ['./addResident.component.css']
})
export class AddResidentComponent implements OnInit {
 loader:boolean=false;
  disasterEvent:any;
  showdiv:boolean=false;
  showloader:boolean=false;
  errorpng:boolean=false;
  userf:any={};
  user:any=[];
  message:string="";
  angForm: FormGroup;
  angForm1:FormGroup;
  shelterSelected:string="";
  disaster:any={};
  disasters:any=[];
  shelter:any={};
  ngoShelters:any=[];
  userDetail:any={};
  previousShelter:string="";
  // sub;
  constructor(@Inject(LOCAL_STORAGE) private storage: WebStorageService,private addShelterService:AddShelterService,private userRegisterService: UserRegisterService,private getDisasterEventsService: GetDisasterEventsService,private globalService: GlobalService,private activatedRoute: ActivatedRoute,private router:Router,private searchpeopleService: SearchpeopleService) {
   
        this.disasterEvent=this.storage.get("disasterEvent");
        this.disaster=this.storage.get("disaster");
        //this.user=this.storage.get("user");
        console.log("disasterEvent here is:"+this.disasterEvent);
        console.log(this.disaster)
        if($.isEmptyObject(this.disaster)){
          console.log("inside empty object")
          this.disaster={
            "Other":""
          }
          this.disasterEvent=0;
        }else{
          this.getSheltersByNGOAndDisaster()
        }

        if($.isEmptyObject(this.userf)){
          this.userf={
            "Addr":{
              "Other":""
            },
            "shelter":[]
          }
          // this.disasterEvent=0;
        }
        this.getAllDisasterEvents();
        // if(this.disasterEvent!=0){
        //   this.getSheltersByNGOAndDisaster();
        // }
        
    // console.log("disaster Id in search constructor: "+this.globalService.getDisasterId());
    this.shelterSelected="";
    this.userf.status="";

  }


   
  
 
  removeFrom(){


    $(".overlaymodal").show();
      this.userRegisterService.updateResident(this.userf).subscribe((data: any) => {
        console.log("output of enlisted...");
        console.log(data);
        $(".overlaymodal").hide();
        if(this.previousShelter==this.shelterSelected){
          $("#messageModal").modal('hide');
        }else{
          this.changeShelter();
        }
      //  this.message="Updated Successfully..!";
      //  this.loader=false;
      // this.errorpng=false;
      // $('#messageModal').modal();
      console.log(data);
    }, error => {
      
       this.message="Something went wrong..!!";
      this.errorpng=true;
       $(".overlaymodal").hide();
       $('#messageModal').modal();
      console.log(error);
    }
    );
    
//     {
//   "$class": "org.disaster.model.ShelterName",
//   "shelter": "org.disaster.model.Shelter#"+this.userf.shelter[0].Shelter_Id,
//   "email": this.userf.Resident_Email,
//   "Id": "123"
// }
    
    // this.ngoShelters[index].shelter=[];
  }

changeShelter(){
  
  console.log("calling remove...");
    var enlist={
  "$class": "org.disaster.model.changeshelterstatus",
  "Biometric": this.userf.Biometric
}
   $(".overlaymodal").show();
    this.addShelterService.changeShelter(enlist).subscribe((data: any) => {

      // this.loader=false;
      // this.errorpng=false;
      // $("#messageModal").modal('hide');
      $(".overlaymodal").hide();
      this.updateResidentShelterByEmail();
      
      console.log(data);
    }, error => {
      
       this.message="Something went wrong..!!";
      this.errorpng=true;
      $(".overlaymodal").hide();
       $('#messageModal').modal();
      console.log(error);
    }
    );
}
  updateResidentShelterByEmail(){

      // this.shelter=this.ngoShelters[this.shelterSelected];

    var enlist={
  "$class": "org.disaster.model.UpdateResidentInShelterByEmail",
  "shelter": "org.disaster.model.Shelter#"+this.shelterSelected,
  "EmailId": this.userf.Resident_Email,
  "shelterId": this.shelterSelected
}
  $(".overlaymodal").show();
    this.addShelterService.updateResidentShelterByEmail(enlist).subscribe((data: any) => {

      // this.loader=false;
      // this.errorpng=false;
      // $("#messageModal").modal('hide');
      $(".overlaymodal").hide();
      this.deleteResidentInfo();
      console.log(data);
    }, error => {
      
       this.message="Something went wrong..!!";
      this.errorpng=true;
       $(".overlaymodal").hide();
       $('#messageModal').modal();
      console.log(error);
    }
    );
  }

  deleteResidentInfo(){

      // this.shelter=this.ngoShelters[this.shelterSelected];

    var enlist={
  "$class": "org.disaster.model.deleteresidentinfo",
  "Sheltername": "org.disaster.model.ShelterName#123"
}
  $(".overlaymodal").show();
    this.addShelterService.deleteResidentInfo(enlist).subscribe((data: any) => {

        this.userf.shelter=[];
        // this.userf.shelter.push(data);
       $(".overlaymodal").hide();
        this.errorpng=false;
        $("#messageModal").modal('hide');
      // this.loader=false;
      // this.errorpng=false;
      // $("#messageModal").modal('hide');
      
      console.log(data);
    }, error => {
      
       this.message="Something went wrong..!!";
      this.errorpng=true;
       $(".overlaymodal").hide();
       $('#messageModal').modal();
      console.log(error);
    }
    );
  }
  showButton:boolean=true;
  selectShelter(use,value){
      this.userf=use;
      if(use.shelter.length==0){
          this.shelterSelected="";
          this.previousShelter="";
      }else{
        this.shelterSelected=use.shelter[0].shelterId.split("#")[1];
        this.previousShelter=this.shelterSelected;
      }
      
      // this.userf.status="";
      this.showdiv=true;
      this.showButton=value;
      
       $("#messageModal").modal();
  }

  ngOnInit() {

    console.log("calling init")
    this.angForm = new FormGroup({
         email: new FormControl('', Validators.compose([
        Validators.required,
        Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
      ]))
     
  
    })

    this.angForm1 = new FormGroup({
         shelterSelected: new FormControl('', Validators.compose([
        Validators.required
    
      ])),

      status: new FormControl('', Validators.compose([
        Validators.required
        
      ]))
     
  
    })
    
    // this.sub = this.activatedRoute.queryParams
    //                 .subscribe(params => { 
    //                  this.disasterEvent = +params['disasterEvent']||0;
    //                  console.log('Query params ',this.disasterEvent) });
   }

   addResident(){
  
     $(".overlaymodal").show();
      this.userRegisterService.updateResident(this.userf).subscribe((data: any) => {
        console.log("output of enlisted...");
        console.log(data);
        $(".overlaymodal").hide();
        this.addEnlistedAffected();
      //  this.message="Updated Successfully..!";
      //  this.loader=false;
      // this.errorpng=false;
      // $('#messageModal').modal();
      console.log(data);
    }, error => {
      
       this.message="Something went wrong..!!";
      this.errorpng=true;
       $(".overlaymodal").hide();
       $('#messageModal').modal();
      console.log(error);
    }
    );
   }

   addEnlistedAffected(){
      
      var enlist={
  "$class": "org.disaster.model.Enlisted_Affected_People_In_Particular_Shelter",
  "shelter": "org.disaster.model.Shelter#"+this.shelterSelected,
  "Biometric": this.userf.Biometric,
  "shelterId": this.shelterSelected
}
    $(".overlaymodal").show();
     this.addShelterService.addEnlistedPeople(enlist).subscribe((data: any) => {

      this.userf.shelter.push(data);
      this.user[0].shelter.push(data);

      $(".overlaymodal").hide();
      this.errorpng=false;
      $("#messageModal").modal('hide');
      
      console.log(data);
    }, error => {
      
       this.message="Something went wrong..!!";
      this.errorpng=true;
       $(".overlaymodal").hide();
       $('#messageModal').modal();
      console.log(error);
    }
    );

   }
   
   showuserDetails(use){
    this.userf=use;
    $('#showmodal').modal();
   }
email:string="";
searchPeopleByEmail() {
    
      
        //this.showdiv=true;
    console.log("here calling servie.......")
    $(".overlay").show();
    this.user=[];
    this.searchpeopleService.searchPeopleByEmail(this.email).subscribe((data: any) => {
      $(".overlay").hide();
      
      if(data.length==0){
          this.message="Person not found with this details..!!"
          this.errorpng=false;
          this.showdiv=false;
      }
    
      else{
        this.errorpng=false;
        this.user.push(data);
        this.showdiv=true;
      }
      console.log(data);
    }, error => {
      $(".overlay").hide();
      this.user=[];
     
      this.showdiv=false;
      this.errorpng=true;
      this.message="Something went wrong.."
      console.log(error);
    }
    );
  }

  getAllDisasterEvents(){
    $(".overlay").show();
    this.getDisasterEventsService.GetDisasterEvents().subscribe((data: any) => {
      $(".overlay").hide();
      this.disasters=data["Events"];
     
        this.errorpng=false;
        
      console.log(data);
    }, error => {
      $(".overlay").hide();
       this.disasters=[];
      this.errorpng=true;
      this.message="Something went wrong.."
      console.log(error);
    }
    );
  }
   hashValue:string="";
   searchByBiometric(){
    $('#biometricModal').modal();
        
    setTimeout(() => {
      this.hashValue="8AD53424AEBB63295673BC782EF12FD6C71ABADB";
      $('#biometricModal').modal('hide');
      this.searchPeopleByBiometric(this.hashValue);
    }, 3000)
  }

  searchPeopleByBiometric(hashValue) {
    $(".overlay").show();
    console.log("here calling servie.......")
    this.searchpeopleService.searchPeopleByBiometric(hashValue).subscribe((data: any) => {
      $(".overlay").hide();
     
      if(data.length==0){
          this.message="Person not found with this details..!!"
          this.errorpng=false;
          this.showdiv=false;
      }
   
      else{
        this.errorpng=false;
        this.user=data;
        this.showdiv=true;
      }
      console.log(data);
    }, error => {
      $(".overlay").hide();
      this.showdiv=false;
      this.errorpng=true;
      this.message="Something went wrong.."
      console.log(error);
    }
    );
  }
   onItemChange(value){
  
   console.log("calling here itemChange function: "+ value);
   this.disasterEvent=parseInt(value)+1;
   this.storage.set("disasterEvent", this.disasterEvent);
   this.storage.set("disaster", this.disasters[value]);
   this.disaster=this.disasters[value];
   this.getSheltersByNGOAndDisaster();
   //this.router.navigate(['./home'], { queryParams: { disasterEvent: this.disasterEvent },relativeTo: this.activatedRoute });
 
 }

 getSheltersByNGOAndDisaster() {
   this.errorpng=false;
   this.userDetail=this.storage.get("user");
   this.ngoShelters=[];
  $(".overlay").show();
    console.log("here calling servie..shelter.....")
    this.getDisasterEventsService.getShelterByDisasterAndNGO(this.disaster.EventName,this.userDetail.NGO_Email).subscribe((data: any) => {
      
      this.ngoShelters = data;
      console.log(this.ngoShelters)
         $(".overlay").hide();
        //this.message="More than one person found.. Please enter unique details.."
          this.errorpng=false;
        this.loader=false;
      
      console.log(data);
    }, error => {
     
      this.ngoShelters =[];
      $(".overlay").hide();
      this.errorpng=true;
      this.message="Something went wrong.."
      console.log(error);
    }
    );
  }
  //  this.disasterEvent = this.activatedRoute.snapshot.queryParamMap.get('disasterEvent');
  //  console.log("disaster event is: "+ this.disasterEvent);
  //}
account_validation_messages = {
    'email': [
      { type: 'required', message: 'Email is required' },
      { type: 'pattern', message: 'Please enter a valid email' }
    ],
    'shelterSelected': [
      { type: 'required', message: 'Shelter is required' },
     
    ],
    'status': [
      { type: 'required', message: 'Status is required' },
   
    ]
  }
}
