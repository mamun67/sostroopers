import { Component,OnInit,Inject } from '@angular/core';
import { WeatherapiService } from  './services/weatherapi/weatherapi.service';
// import { ChangepwdService } from  './services/changepwd/changepwd.service';
import { LoginService } from  './services/login/login.service';
import { GlobalService } from  './services/global/global.service';
import { ActivatedRoute,Router} from '@angular/router';
import { PasswordValidation } from './matchPwd/matchPwd.component';
import { GetDisasterEventsService} from './services/getdisasterevents/getdisasterevents.service';
import {LOCAL_STORAGE, WebStorageService} from 'angular-webstorage-service';
import { FormGroup, Validators, FormControl, FormBuilder } from '@angular/forms';

declare var jquery: any;
declare var $: any; 

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  netImage:any;
  newUser:any;
  login:boolean;
  error:any;
  angForm: FormGroup;
   angForm1: FormGroup;
   disasterEvent:any;
   usernew:any={};
   loader:boolean=false;
    errorpng:boolean=false;
    message:string=""; 
    disasters:any=[];
    loginFail:boolean=false;
    user:any={};
//    sub;
//  
  private  weather:any={}

temp:number;
humidity:number;
weatherdesc:number;
presentday:string;
currentWeather:any;
currentDayShift:any;
showWeather:boolean=false;
disaster:any={};
messageone:string="Sorry..!! No Live Reports";
  constructor(@Inject(LOCAL_STORAGE) private storage: WebStorageService,private getDisasterEventsService:GetDisasterEventsService,private  globalService:  GlobalService,private activatedRoute:ActivatedRoute,private router:Router,private  loginService:  LoginService,private  weatherapiService:  WeatherapiService,  private fb: FormBuilder) {
       console.log("calling app component constructor......");
        this.login=this.storage.get("login");
        this.user=this.storage.get("user");
        if($.isEmptyObject(this.user)){
          this.user={
            "Role":""
          }
        }
        this.disasterEvent=this.storage.get("disasterEvent");
   this.disaster=this.storage.get("disaster");
   if($.isEmptyObject(this.disaster)){
          this.disaster={
            "Other":""
          }
          this.disasterEvent=0;
        }
     
      if(this.disasterEvent==0){
        console.log("here called modal app***************************");
         $("#modal").modal();
      }
     this.newUser={};
  }
    changeWeather(currentWeather:any,currentDayShift:any){
         this.presentday=currentWeather.fcst_valid_local;
         this.weatherdesc=currentDayShift.phrase_22char;
         this.humidity=currentDayShift.rh;
         this.temp=Math.round((currentDayShift.temp-32)/1.8);
         this.netImage= "../assets/weathericons/icon"+currentDayShift.icon_code+".png";
         this.currentWeather=currentWeather;
    }
      loginFunc(){
        this.loginFail=false;
        this.angForm1.reset();
      }
    getWeather(lat,longi){
        var body={
          "lat":lat+"",
          "lon":longi+""
      } 
 

    this.weatherapiService.getWeatherDetails(body).subscribe((data: any) => {

        this.weather  =  data["body"];
      // Date.parse(new Date().toString())<=Date.parse(this.currentWeather.sunset)
         this.currentWeather=this.weather.forecasts[0];
         console.log("current weatgher:------");
         console.log(this.currentWeather);
   if(this.currentWeather.hasOwnProperty("day")){
        this.currentDayShift=this.currentWeather.day;
       this.netImage= "../assets/weathericons/icon"+this.weather.forecasts[0].day.icon_code+".png";
      this.temp=Math.round((this.currentDayShift.temp-32)/1.8);
      this.humidity=this.currentDayShift.rh;
      this.weatherdesc=this.currentDayShift.phrase_22char;
      this.presentday=this.currentDayShift.fcst_valid_local;
    }
    else {
        this.currentDayShift=this.currentWeather.night;
       this.netImage= "../assets/weathericons/icon"+this.currentDayShift.icon_code+".png";
      this.temp=Math.round((this.currentDayShift.temp-32)/1.8);
      this.humidity=this.currentDayShift.rh;
      this.weatherdesc=this.currentDayShift.phrase_22char;
      this.presentday=this.currentDayShift.fcst_valid_local;
    }
     this.showWeather=true;
        console.log(data);
      }, error => {
        this.error = error // error path);
       this.showWeather=false;
       this.messageone="Sorry..!! No Live Reports";
        console.log("error in weather loading..!!!");
       console.log(this.error);
      }
    );
 
 }



 userLogin(){
  //  this.login=true;
  var usertype="";
  if(this.usernew.userType=="resident"){
    usertype="Resident";
  }
  else if(this.usernew.userType=="ngo"){
    usertype="NGO";
  }
  else if(this.usernew.userType=="admin"){
    usertype="Site_Admin";
  }
  var newUse={
  "$class": "org.disaster.model.verifyUser",
  "UserName": this.usernew.username,
  "Password": this.usernew.password,
  "Role": usertype
  
}
 this.login=false;
  $(".overlaymodal").show();
   console.log("calling here login function: "+ this.login);
    this.loginService.login(newUse).subscribe((data: any) => {
          this.loginFail=false;
          
          $(".overlaymodal").hide();
           
         
         if(typeof(data["body"])==typeof("hello")){
           this.login=false;
           this.loginFail=true;
           this.storage.set("login", false);
           this.storage.set("user", {});
           this.angForm1.reset();
         }else{
            $("#loginmodal").hide();
           this.login=true;
            this.user=data["body"];
           this.user["Role"]=this.usernew.userType;
           this.loginFail=false;
          // this.globalService.setUser(this.user);
          this.storage.set("login", true);
           this.storage.set("user", this.user);
           this.router.navigate(["/home"]);
           this.angForm1.reset();
           location.reload(true);
          window.location.href="https://webapp-sos-troopers-surprised-hippopotamus.mybluemix.net";
         }
          
          
          //location.reload(true);

        //this.login  =  data;
        
        console.log(data);
      }, error => {
        this.error = error // error path);
        
            this.loginFail=true;
            this.storage.set("login", false);
           this.storage.set("user", {});
             $(".overlaymodal").hide();
            this.login=false;
            this.angForm1.reset();
       //this.login=false;
       console.log(this.error);
      }
    );
 
 }

  logout(){
   this.login=false;
   this.loginFail=true;
    this.storage.set("login", false);
    this.storage.set("user", {});
    this.storage.set("disasterEvent", 0);
    this.storage.set("disaster", {});
   var user={};

   this.disasterEvent=0;
   this.router.navigate(["/home"]);
 }
changepwdFail:boolean=false;
 changePwd(){
   var userl={};
   var role=this.user.Role;
   this.user=this.storage.get("user");
   this.changepwdFail=false;
   var url="";
   if(this.user.Role=='resident'){
      url="https://disaster-business-network-blockchain-dda8f00fb8745b9c1e48.mybluemix.net/api/Resident/"+this.user.Resident_Email;
   }
   else if(this.user.Role=='ngo'){
      url="https://disaster-business-network-blockchain-dda8f00fb8745b9c1e48.mybluemix.net/api/NGO/"+this.user.NGO_Email;
   }
   else if(this.user.Role=='admin'){
      url="https://disaster-business-network-blockchain-dda8f00fb8745b9c1e48.mybluemix.net/api/Site_Admin/"+this.user.Admin_Email;
   }
   this.user.Password=this.newUser.password;
   userl=this.user;
   delete userl["Role"];
    $(".overlaymodal").show();
    this.loginService.updatePwd(url,userl).subscribe((data: any) => {
         
          console.log("user");
          console.log(data);
          data["Role"]=role;
          this.storage.set("user", data);
          this.user=data
           $(".overlaymodal").hide();
          this.angForm.reset();
          this.changepwdFail=false;
          $("#changePwdModal").modal('hide');
          window.location.href="https://webapp-sos-troopers-surprised-hippopotamus.mybluemix.net";
        //this.login  =  data;
  
        console.log(data);
      }, error => {
        this.error = error // error path);
         $(".overlaymodal").hide();
            this.changepwdFail=true;
            this.angForm.reset();
       //this.login=false;
       console.log(this.error);
      }
    );
 }
 
  getAllDisasterEvents(){
    $(".overlay").show();
   this.errorpng=false;
    console.log("here calling servie.......")
    this.getDisasterEventsService.GetDisasterEvents().subscribe((data: any) => {

      this.disasters = data["Events"];
      $(".overlay").hide();
        //this.message="More than one person found.. Please enter unique details.."
          this.errorpng=false;
        
      
      console.log(data);
    }, error => {
     // error path);
    this.disasters=[];
      this.errorpng=true;
       $(".overlay").hide();
      this.message="Something went wrong.."
      $('#viewmodal').modal();
      console.log(error);
    }
    );
  }
 onItemChange(value){
  
   console.log("calling here itemChange function: "+ value);
      this.disasterEvent=parseInt(value)+1;
      this.storage.set("disasterEvent", this.disasterEvent);
      this.storage.set("disaster", this.disasters[value]);
      this.disaster=this.disasters[value];
      console.log("disaster Id in skip app itemChange: "+this.globalService.getDisasterId());
      this.router.navigate(['./home']);
 
 }

  skip(){
  
   console.log("calling here skip function: ");
   this.disasterEvent=0;
   this.storage.set("disasterEvent", this.disasterEvent);
   this.storage.set("disaster", {});
    console.log("disaster Id in skip app: "+this.globalService.getDisasterId());
   this.router.navigate(['./home']);
    
 
 }


 ngOnInit(){

      if (window.navigator && window.navigator.geolocation) {
        window.navigator.geolocation.getCurrentPosition(
            position => {
                var lat = position.coords.latitude;
                var lng = position.coords.longitude;
                    console.log(position)
                    this.getWeather(lat,lng);
            },
            error => {
                switch (error.code) {
                    case 1:
                        console.log('Permission Denied');
                        break;
                    case 2:
                        console.log('Position Unavailable');
                        break;
                    case 3:
                        console.log('Timeout');
                        break;
                }
            }
        );
    };
  // this.getWeather();
  this.angForm = new FormGroup({

       pwd: new FormControl('',Validators.compose([
        Validators.required
      
      ])),
      repwd: new FormControl('',Validators.compose([
        PasswordValidation

  
      ]))

  })

        //  this.angForm.controls.pwd.valueChanges
        //  .subscribe(
        //   x=> this.angForm.controls.repwd.updateValueAndValidity()
  //  )

   this.angForm1 = new FormGroup({

       username: new FormControl('',Validators.compose([
        Validators.required,
         Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
      ])),
      password: new FormControl('',Validators.compose([
        Validators.required
      ])),
      usertype: new FormControl('',Validators.compose([
        Validators.required
      ]))

  })


 
 }

 account_validation_messages = {
     'pwd': [
      { type: 'required', message: 'Password is required' }
    ],
      'usertype': [
      { type: 'required', message: 'User type is required' }
    ],
     'username': [
      { type: 'required', message: 'Username is required' },
     { type: 'pattern', message: 'Please enter valid email' }
    ],


    'repassword': [
      { type: 'required', message: 'Password is required' }
    ],
   

 'repwd': [
      { type: 'isError', message: 'Password & Confirm Password Not Matched' }
    ]
 }


}
