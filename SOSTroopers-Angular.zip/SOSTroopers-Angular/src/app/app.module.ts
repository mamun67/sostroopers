import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { UserRegComponent } from './userreg/userreg.component';
import { AccountComponent } from './account/account.component';
import { AgmCoreModule } from '@agm/core';
import { WeatherapiService } from  './services/weatherapi/weatherapi.service';
import { NGORegisterService } from  './services/ngoregister/ngoregister.service';
import { UserRegisterService } from  './services/userregister/userregister.service';
import { HttpClientModule } from '@angular/common/http';
import { NGORegComponent } from './ngoreg/ngoreg.component';
import { PeopleSearchComponent } from './searchPeople/searchPeople.component';
import { ViewprofileComponent } from './viewprofile/viewprofile.component';
import { SearchShelterComponent } from './searchShelter/searchShelter.component';
import { GetDisasterEventsComponent } from './getDisasterEvents/getDisasterEvents.component';
import { RespondComponent } from './respond/respond.component';
import { GetNGOsComponent } from './getNGOs/getNGOs.component';
import { CreateDisasterEventComponent } from './createDisasterEvent/createDisasterEvent.component';
import { UpdateDisasterEventComponent } from './UpdateDisasterEvent/UpdateDisasterEvent.component';
import { AddResidentComponent } from './addResident/addResident.component';
import { ActiveEventsComponent } from './activeEvents/activeEvents.component';
import { PastEventsComponent } from './pastEvents/pastEvents.component';
import { RequestsComponent } from './requests/requests.component';
import { NotificationsComponent } from './notifications/notifications.component';
import { AdminRequestsComponent } from './adminRequests/adminRequests.component';
import { UpdateResidentComponent } from './updateResident/updateResident.component';
import { ShowShelterComponent } from './showShelter/showShelter.component';
import { DateAscending } from './datePipe/dateascend';
import {FilterPipe} from './statusPipe/statusPipe';
import { LoginService } from './services/login/login.service';
import { AddShelterService } from './services/addShelter/addShelter.service';
import { GlobalService } from './services/global/global.service';
import { SearchpeopleService } from './services/searchpeople/searchpeople.service';
import { GetDisasterEventsService } from './services/getdisasterevents/getdisasterevents.service';
import { GetAllNGOsService } from './services/getallngos/getallngos.service';
import { CreateDisasterService } from './services/createdisaster/createdisaster.service';
import { CreateShelterService } from './services/createshelter/createshelter.service';
import { RequestsService } from './services/requests/requests.service';
import { GetShelterByDisasterService} from './services/getShelterByDisaster/getShelterByDisaster.service';
// import {MatSelectModule,MatFormFieldModule,MatInputModule} from '@angular/material';
// import {BrowserAnimationsModule, NoopAnimationsModule} from '@angular/platform-browser/animations';
import { StorageServiceModule} from 'angular-webstorage-service';


const routes: Routes = [
  { path: '', redirectTo:'/home',pathMatch: 'full'},
  { path: 'home',component: AccountComponent},
  { path: 'userReg', component: UserRegComponent },
  { path: 'ngoReg', component: NGORegComponent },
   { path: 'searchPeople', component: PeopleSearchComponent },
    { path: 'viewProfile', component: ViewprofileComponent },
      { path: 'searchShelters', component: SearchShelterComponent },
      // {path: '', component: PeopleSearchComponent},
       {path: 'createDisasterEvent', component: CreateDisasterEventComponent},
       {path: 'getDisasterEvents', component: GetDisasterEventsComponent},
       {path: 'eventRegister', component: RespondComponent},
        {path: 'updateDisasterEvent', component: UpdateDisasterEventComponent},
        {path: 'addResident', component: AddResidentComponent},
        {path: 'activeEvents', component: ActiveEventsComponent},
           {path: 'pastEvents', component: PastEventsComponent},
           {path: 'requests', component: RequestsComponent},
           {path: 'adminRequests', component: AdminRequestsComponent},
            {path: 'getNGOs', component: GetNGOsComponent},
            {path: 'updateProfile', component: UpdateResidentComponent},
            {path: 'showShelter', component: ShowShelterComponent},
            {path: 'showNotifications', component: NotificationsComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    UserRegComponent,
    UpdateResidentComponent,
    AccountComponent,
    NGORegComponent,
    PeopleSearchComponent,
    ViewprofileComponent,
    SearchShelterComponent,
    NotificationsComponent,
    GetDisasterEventsComponent,
    RespondComponent,
    CreateDisasterEventComponent,
    UpdateDisasterEventComponent,
    AddResidentComponent,
    ActiveEventsComponent,
    PastEventsComponent,
    RequestsComponent,
    AdminRequestsComponent,
    DateAscending,
    FilterPipe,
    GetNGOsComponent,
ShowShelterComponent
  ],
  imports: [
    BrowserModule,
    StorageServiceModule,
    RouterModule.forRoot(routes),
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyAMheM_sM-6szkdoyBEeEjgPDqBe5W4pnE'
    }),
     HttpClientModule,
     FormsModule,
      ReactiveFormsModule
      // MatSelectModule,
      // BrowserAnimationsModule,
      // NoopAnimationsModule,
      // MatFormFieldModule,
      // MatInputModule
  ],
  providers: [WeatherapiService,
LoginService,
  NGORegisterService,
  UserRegisterService,
  AddShelterService,
  GlobalService,
  SearchpeopleService,
  GetDisasterEventsService,
  GetAllNGOsService,
CreateDisasterService,
GetShelterByDisasterService,
CreateShelterService,
RequestsService

  ],
  bootstrap: [AppComponent]
})


export class AppModule { 
}
