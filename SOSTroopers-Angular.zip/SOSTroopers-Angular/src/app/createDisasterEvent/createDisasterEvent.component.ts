import { Component, OnInit, Inject } from '@angular/core';
import { CreateDisasterService } from '../services/createdisaster/createdisaster.service';
import { GlobalService } from '../services/global/global.service';
import { FormGroup, Validators, FormControl, FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router} from '@angular/router';
import {LOCAL_STORAGE, WebStorageService} from 'angular-webstorage-service';

declare var jquery: any;
declare var $: any;
declare function myMethod():any;

@Component({
  selector: 'app-create-disaster-event',
  templateUrl: './createDisasterEvent.component.html',
  styleUrls: ['./createDisasterEvent.component.css']
})
export class CreateDisasterEventComponent implements OnInit {
  disaster: any;
  response: any;
  error: any;
  angForm: FormGroup;
  shelter:boolean=false;
  medical:boolean=false;
  serviceProvide:any=[];
  country:string;
  loader:boolean=false;
  constructor(@Inject(LOCAL_STORAGE) private storage: WebStorageService,private activatedRoute: ActivatedRoute,private router:Router, @Inject(CreateDisasterService) private createDisasterService: CreateDisasterService,private globalService: GlobalService, private fb: FormBuilder) {
    this.disaster = {};
    this.disaster.Type_Of_Disaster=-1;
    this.country="-1";
  }

   message:string="";
  errorpng:boolean=false;
 state:string;
 dd:any;
 mm:any;
 AreaAffected:string="";
  createDisaster() {
     $(".overlay").show();
    this.disaster["$class"] = "org.disaster.model.Disaster_Event";
    this.disaster["status"] = true;
    this.disaster["ngos"] = [];
    this.disaster["loc"] =  
    {
      "$class": "org.disaster.model.DisLocation",
      "State": this.state,
      "Country": this.country
    } ;
    var areas=[];
    for(let i=0;i<this.AreaAffected.split(",").length;i++){
      areas.push(this.AreaAffected.split(",")[i].trim());

    }

    if (this.shelter) {
      this.serviceProvide.push('Shelter');
    }
    if (this.medical) {
      this.serviceProvide.push('Medical');
    }

    this.disaster["AreaAffected"]=areas;
    this.disaster["Types_Of_Help_Needed"]=this.serviceProvide;
    var date=new Date();
    this.dd=date.getDate();
    this.mm=date.getMonth();
    if(this.dd<10){
      this.dd="0"+this.dd;
    }
    if(this.mm<10){
      this.mm="0"+this.mm;
    }
    this.disaster["Created_Date"]=date.getFullYear()+"-"+this.mm+"-"+this.dd;
    this.disaster["CreatedBy"]="resource:org.disaster.model.Site_Admin#"+this.storage.get("user").Admin_Email;
    console.log("here calling servie.......")
    this.createDisasterService.createDisaster(this.disaster).subscribe((data: any) => {
       $(".overlay").hide();
      this.response = data;
       this.message="Created disaster event successfully..!";
      this.errorpng=false;
      this.sendNotify(this.disaster);
      this.angForm.reset();
     // $("#messageModal").modal();
      console.log(data);
    }, error => {
      this.error = error // error path);
       this.message="Something went wrong..!!";
      this.errorpng=true;
      $(".overlay").hide();
      $("#messageModal").modal();
      console.log(this.error);
    }
    );
  }

sendNotify(disaster){
  var body={
    "eventID":disaster.EventName,
    "eventDescription":disaster.Disaster_details
}
   $(".overlay").show();
  this.createDisasterService.sendNotify(body).subscribe((data: any) => {
       $(".overlay").hide();
      // this.response = data;
      this.message="Sent Notification Successfully..!";
      this.errorpng=false;
      // this.angForm.reset();
       $("#messageModal").modal();
      console.log(data);
    }, error => {
      this.error = error // error path);
       this.message="Something went wrong..!!";
      this.errorpng=true;
      $(".overlay").hide();
      $("#messageModal").modal();
      console.log(this.error);
    }
    );
}
 
  redirect(){
    this.router.navigate(['./home']);
  }
  ngOnInit() {
    myMethod();

    this.angForm = new FormGroup({
      name: new FormControl('', Validators.compose([
        Validators.required,
        Validators.maxLength(25),
        Validators.minLength(5),
        Validators.pattern('^[A-Za-z ]+$')
      ])),

      typeofdisaster: new FormControl('', Validators.compose([
        Validators.required
      ])),


      country: new FormControl('', Validators.compose([
        Validators.required
      ])),

      state: new FormControl('', Validators.compose([
        Validators.required
      ])),

      // dod: new FormControl('', Validators.compose([
      //   Validators.required
      // ])),

      areasaffected: new FormControl('', Validators.compose([
        Validators.required,
        Validators.minLength(3),
        Validators.pattern('^[A-Za-z0-9 ,]+$')
        
      ])),
      shelter: new FormControl(''),
      medical: new FormControl(''),
      description: new FormControl('')


    })
  }

  account_validation_messages = {
    'name': [
      { type: 'required', message: 'Name is required' },
      { type: 'minlength', message: 'Name must be at least 5 characters long' },
      { type: 'maxlength', message: 'Name cannot be more than 25 characters long' },
      { type: 'pattern', message: 'Name must contain only letters' }
    ],

    'typeofdisaster': [
      { type: 'required', message: 'Must select disaster type' }
     
    ],

    'country': [
      { type: 'required', message: 'Country is required' }
    
      
    ],


    'state': [
      { type: 'required', message: 'State is required' }
    ],

    // 'dod': [
    //   { type: 'required', message: 'Date of disaster happened is required' }
    // ],


    'areasaffected': [
      { type: 'required', message: 'Areas affected is required' },
      { type: 'minlength', message: 'Areas affected must be at least 3 characters long' },
      { type: 'pattern', message: 'Areas affected must contain characters (A-Za-z0-9 ,) only' }
    ]

  }

}
