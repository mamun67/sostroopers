import { Component, OnInit, Inject } from '@angular/core';
import { ActivatedRoute, Router} from '@angular/router';
import { CreateDisasterService } from '../services/createdisaster/createdisaster.service';
import { GetDisasterEventsService} from '../services/getdisasterevents/getdisasterevents.service';
import { FormGroup, Validators, FormControl, FormBuilder } from '@angular/forms';
import { CreateShelterService } from '../services/createshelter/createshelter.service';
import { GetAllNGOsService } from '../services/getallngos/getallngos.service';
import {LOCAL_STORAGE, WebStorageService} from 'angular-webstorage-service';

declare var jquery: any;
declare var $: any; 

declare function showTabsFunc():any;


@Component({
  selector: 'app-get-disaster-events',
  templateUrl: './getDisasterEvents.component.html',
  styleUrls: ['./getDisasterEvents.component.css']
})
export class GetDisasterEventsComponent implements OnInit {
  allDisasters:any;
  error:any;
  message:string="";
  errorpng:boolean;
  disasters:any={};
  helpNeeded:string="";
  showData:string="ngo";
  loader:boolean=false;
  angForm: FormGroup;
  country:string;
  state:string;
  district:string;
  zipcode:string;
  other:string;
  AreaName:string;
  showDiv:string='';
  constructor(private getAllNGOsService:GetAllNGOsService,@Inject(LOCAL_STORAGE) private storage: WebStorageService,private activatedRoute: ActivatedRoute,private router:Router,private getDisasterEvents:GetDisasterEventsService,private createShelterService:CreateShelterService,private createDisasterService:CreateDisasterService) {
      this.loader=true;
      this.allDisasters=[];
      this.getAllDisasterEvents();

  }

  ngOnInit() {
    console.log("calling init");

    this.angForm = new FormGroup({
      name: new FormControl('', Validators.compose([
        Validators.required,
        Validators.maxLength(25),
        Validators.pattern('^[A-Za-z1-9 ]+$')
      ])),

      
      
       lat:new FormControl('',Validators.compose([
        Validators.required,
        Validators.pattern('^[0-9.-]+$')
      ])),
      longi:new FormControl('',Validators.compose([
        Validators.required,
        Validators.pattern('^[0-9.-]+$')
      ]))

    })
 
  }


 showtabs:boolean=false;

 getAllDisasterEvents(){
    this.loader=true;
    $(".overlay").show();
   
    this.getDisasterEvents.GetDisasterEvents().subscribe((data: any) => {
       $(".overlay").hide();
      this.allDisasters=data["Events"];
      this.loader=false;
        this.errorpng=false;
        
      console.log(data);
    }, error => {
      $(".overlay").hide();
      this.confirm=false;
      this.errorpng=true;
      this.loader=false;
      this.message="Something went wrong.."
      $("#messageModal").modal();
      console.log(error);
    }
    );
  }
  
  dd:any;
  mm:any;
  confirm:boolean=false;
  confirmMessage:string="";
  closeEvent(disaster){
    this.disasters=disaster;
    var date=new Date();
    this.dd=date.getDate();
    this.mm=date.getMonth();
    if(this.dd<10){
      this.dd="0"+this.dd;
    }
    if(this.mm<10){
      this.mm="0"+this.mm;
    }
    this.disasters["End_Date"]=date.getFullYear()+"-"+this.mm+"-"+this.dd;
    this.disasters["status"]=false;
    $(".overlay").show();
    this.createDisasterService.updateDisaster(this.disasters).subscribe((data: any) => {
      this.errorpng=false; 
      $(".overlay").hide();
      console.log(data);
    }, error => {
      this.confirm=false;
      $(".overlay").hide();
      this.disasters["status"]=true;
       this.message="Something went wrong..!!";
      this.errorpng=true;
      $("#messageModal").modal();
      console.log(error);
    }
    );

  }

  closeEventConfirm(disaster){
    console.log("calling close event function....");
    console.log(disaster);
    this.disasters=disaster;
    this.confirm=true;
    this.confirmMessage="Do you want close "+this.disasters.EventName+" event?";
    console.log("before calling modalfunction...."+ this.confirmMessage);
    // $("#messageModalshow").modal();
  }
  availNGOs:any=[];
   showModal(disaster){
      this.showtabs=true;
     this.helpNeeded="";
     this.disasters=disaster;
     this.login=true;
     if(this.disasters.Types_Of_Help_Needed.length!=0){
       this.helpNeeded=this.disasters.Types_Of_Help_Needed[0];
     }
     
     for(let index=1; index<this.disasters.Types_Of_Help_Needed.length; index++){
       this.helpNeeded=this.helpNeeded+","+this.disasters.Types_Of_Help_Needed[index];
     }
     
     var count=0;
   this.availNGOs=[];
    $(".overlay").show();
     for(let i=0;i<disaster.ngos.length;i++){

       this.getAllNGOsService.getNGO(disaster.ngos[i].ngo).subscribe((data: any) => {

      count=count+1;
      this.availNGOs.push(data);
      if(count==disaster.ngos.length){
      $(".overlay").hide();
      this.errorpng=false;
      this.login=false;
     
    }
      console.log(data);
    }, error => {
      $(".overlay").hide();
      this.login=false;
      this.error = error // error path);
      console.log(this.error);
    }
    );
       
     }
    
     setTimeout(() => {
         $("#defaultOpen").click();
    }, 3)
  

   }

   openModal(value){
  this.showDiv=value;
 }


   branches:string="";
   ngos:any={};
   ngoServcices:string="";
   address:string="";
   showbranches:boolean=false;
   showNGOModal(ngo){
         
     this.ngoServcices="";
     this.branches="";
    this.ngos=ngo;
    if(this.ngos.Addr.Other.trim()==''){
          this.address=this.ngos.Addr.Area+","+this.ngos.Addr.District
     +","+this.ngos.Addr.State+","+this.ngos.Addr.Country+","+this.ngos.Addr.Zip_Code;
    }else{
        this.address=this.ngos.Addr.Other+","+this.ngos.Addr.Area+","+this.ngos.Addr.District
     +","+this.ngos.Addr.State+","+this.ngos.Addr.Country+","+this.ngos.Addr.Zip_Code;
    }
     
    this.showbranches=false;
     
     
     if(this.ngos.ServicesProvide.length!=0){
       this.ngoServcices=this.ngos.ServicesProvide[0];
     }

   
     
     for(let index=1; index<this.ngos.ServicesProvide.length; index++){
       this.ngoServcices=this.ngoServcices+","+this.ngos.ServicesProvide[index];
     }

     
    
     $("#showmodal").modal();
  

   }
   
   addShelterWindow(disasters,ngo){
     this.showData="create";
     this.disasters=disasters;
     this.ngos=ngo;
   }

   newShelt:any={};
   ShelterName:string="";
   lat:any;
   longi:any;
   createShelter(){

  this.newShelt= {
  "$class": "org.disaster.model.Shelter",
  "Shelter_Id": this.ShelterName,
  "Total_Capacity": 0,
  "location": {
    "$class": "org.disaster.model.Location",
    "latitude": this.lat,
    "longititude": this.longi  
  },
  "CurrentPeople": 0,
  "Contact": this.ngos.Contact,
  "vacancy":0,
  "No_Of_doctors": 0,
  "No_Of_Volunteer": 0,
  "available_Equipment": [],
  "available_Amenities": [],
  "resident": [],
  "disevent": this.disasters,
  "ngo": this.ngos
}
    $(".overlay").show();
    this.createShelterService.createShelter(this.newShelt).subscribe((data: any) => {
      $(".overlay").hide();
        this.errorpng=false;
        this.showData="ngo";
      console.log(data);
    }, error => {
      $(".overlay").hide();
      this.confirm=false;
      this.errorpng=true;
      this.message="Something went wrong.."
      $("#messageModal").modal();
      console.log(error);
    }
    );
   }

shelter:any={};
    showShelter(shelt){
    
   this.shelter=shelt;
   $("#showShelter").modal();
 }
login:boolean=false;
availShelters:any=[];
 viewShelterWindow(disasters,ngo){
   this.disasters=disasters;
   this.ngos=ngo;
   this.showData='view';
   this.login=true;
   $(".overlay").show();
   this.createShelterService.getShelterByNGODisaster(this.disasters.EventName,this.ngos.NGO_Email).subscribe((data: any) => {
      $(".overlay").hide();
        this.errorpng=false;
        this.availShelters=data;
      console.log(data);
    }, error => {
      $(".overlay").hide();
      this.confirm=false;
      this.errorpng=true;
       this.login=false;
      this.availShelters=[];
      this.message="Something went wrong.."
      // $("#messageModal").modal();
      console.log(error);
    }
    );
 }
  //  ngo:any={};
  //  updateNgo(index,value){
  //    this.ngo=this.disasters.ngos[index];
  //  }

  account_validation_messages = {
    'name': [
      { type: 'required', message: 'Name is required' },
      { type: 'maxlength', message: 'Name cannot be more than 25 characters long' },
      { type: 'pattern', message: 'Name must contain only alphabets and numbers' }
    ],

     
    
    'lat': [
      { type: 'required', message: 'Latitude is required' },
 
      { type: 'pattern', message: 'Please enter numbers only' }
    ],
     'longi': [
      { type: 'required', message: 'Longitude is required' },
 
      { type: 'pattern', message: 'Please enter numbers only' }
    ]
  }

}
