import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router} from '@angular/router';
// import { CreateDisasterService } from '../services/createdisaster/createdisaster.service';
import { GetDisasterEventsService} from '../services/getdisasterevents/getdisasterevents.service';
import { GetAllNGOsService } from '../services/getallngos/getallngos.service';
declare var jquery: any;
declare var $: any; 

declare function showTabsFunc():any;

@Component({
  selector: 'app-get-ngos',
  templateUrl: './getNGOs.component.html',
  styleUrls: ['./getNGOs.component.css']
})
export class GetNGOsComponent implements OnInit {
  allNGOs:any;
  error:any;
  message:string="";
  errorpng:boolean;
  showbranches:boolean=false;
  ngos:any={};
  servicesProvide:string="";
  address:string="";
  constructor(private getDisasterEventsService:GetDisasterEventsService,private activatedRoute: ActivatedRoute,private router:Router,private getallngos:GetAllNGOsService) {
  this.allNGOs=[];
  this.getAllNGOs();

  }

  ngOnInit() {
    console.log("calling init")
    // this.getAllNGOs();
    // this.sub = this.activatedRoute.queryParams
    //                 .subscribe(params => { 
    //                  this.disasterEvent = +params['disasterEvent']||0;
    //                  console.log('Query params ',this.disasterEvent) });
   }
showtabs:boolean=false;
loader:boolean=false;


  getAllNGOs() {
   this.errorpng=false;
    $(".overlay").show();
    console.log("here calling servie.......")
    this.getallngos.getAllNGOs().subscribe((data: any) => {

      this.allNGOs = data["Events"];
      console.log("inside getallngos .....");
      console.log(this.allNGOs);
          this.errorpng=false;
         $(".overlay").hide();
      
      console.log(data);
    }, error => {
      this.error = error // error path);
      this.confirm=false;
      $(".overlay").hide();
      this.errorpng=true;
      this.allNGOs=[];
      this.message="Something went wrong.."
      $("#messageModal").modal();
      console.log(this.error);
    }
    );
  }
  
  // dd:any;
  // mm:any;
  confirm:boolean=false;
  confirmMessage:string="";
  updateNGO(value){
    if(value){
       $(".overlay").show();
    this.getallngos.updateNGO(this.ngos).subscribe((data: any) => {
      this.errorpng=false; 
       $(".overlay").hide();
      console.log(data);
    }, error => {
      this.confirm=false;
       $(".overlay").hide();
      // this.ngos["Blacklist"]=false;
      this.ngos["Blacklist"]=!this.ngos["Blacklist"];
       this.message="Something went wrong..!!";
      this.errorpng=true;
      $("#messageModal").modal();
      console.log(error);
    }
    );
    }else{
      this.ngos["Blacklist"]=!this.ngos["Blacklist"];
    }
    

  }
ngoIndex:any;
  addToBlackConfirm(index,value){
    this.ngos=this.allNGOs[index];
    this.ngos["Blacklist"]=value;
    this.ngoIndex=index;
    this.confirm=true;
    if(value){
      this.confirmMessage="Do you want to add  "+this.ngos.Name+" ngo to Blacklist?";
    }else{
      this.confirmMessage="Do you want to remove  "+this.ngos.Name+" ngo from Blacklist?";
    }
    
    $('#messageModal').modal();
  }
  availActive:any=[];
  availPast:any=[];

   getActiveAvail(ngo){
      console.log("hitting for active dis...");
     var count=0;
   this.availActive=[];
    $(".overlay").show();
     for(let i=0;i<ngo.Active_event.length;i++){

       this.getDisasterEventsService.getDisasterById(ngo.Active_event[i].disasater.split("#")[1]).subscribe((data: any) => {

      count=count+1;
      this.availActive.push(data);
      if(count==ngo.Active_event.length){
      $(".overlay").hide();
      this.errorpng=false;
     
    }
      console.log(data);
    }, error => {
      $(".overlay").hide();
      this.error = error // error path);
      console.log(this.error);
    }
    );
       
     }

   }
   getPastAvail(ngo){
console.log("hitting for past dis...")
     var count=0;
   this.availPast=[];
    $(".overlay").show();
     for(let i=0;i<ngo.Past_Disaster.length;i++){

       this.getDisasterEventsService.getDisasterById(ngo.Past_Disaster[i].split("#")[1]).subscribe((data: any) => {

      count=count+1;
      this.availPast.push(data);
      if(count==ngo.Past_Disaster.length){
      $(".overlay").hide();
      this.errorpng=false;
     
    }
      console.log(data);
    }, error => {
      $(".overlay").hide();
      this.error = error // error path);
      console.log(this.error);
    }
    );
       
     }

   }
 
   showModal(ngo){
         this.showtabs=true;
     this.servicesProvide="";
     
          this.ngos=ngo;
          if(this.ngos.Addr.Other.trim()!=""){
              this.address=this.ngos.Addr.Other+","+this.ngos.Addr.Area+","+this.ngos.Addr.District
     +","+this.ngos.Addr.State+","+this.ngos.Addr.Country+","+this.ngos.Addr.Zip_Code;
          }else{
            this.address=this.ngos.Addr.Area+","+this.ngos.Addr.District
     +","+this.ngos.Addr.State+","+this.ngos.Addr.Country+","+this.ngos.Addr.Zip_Code;
          }
     

     if(this.ngos.ServicesProvide.length!=0){
       this.servicesProvide=this.ngos.ServicesProvide[0];
     }

     
     for(let index=1; index<this.ngos.ServicesProvide.length; index++){
       this.servicesProvide=this.servicesProvide+","+this.ngos.ServicesProvide[index];
     }

    
     this.getActiveAvail(ngo);
     this.getPastAvail(ngo);
      
     setTimeout(() => {
         $("#defaultOpen").click();
    }, 3)
  

   }

  
  //  ngo:any={};
  //  updateNgo(index,value){
  //    this.ngo=this.disasters.ngos[index];
  //  }

}
