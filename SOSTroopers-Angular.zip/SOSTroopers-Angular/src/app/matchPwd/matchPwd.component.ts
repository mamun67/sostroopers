import {AbstractControl}  from '@angular/forms';

// import {AbstractControl} from '@angular/forms';

export function PasswordValidation (control: AbstractControl){

  if(control && (control.value !==null || control.value !== undefined)){
        const confirm=control.value;
        const passControl=control.root.get('pwd');
        if(passControl){
          const passValue=passControl.value;
          if(passValue !== confirm || passValue==''){
            return{
              isError:true
            };
          }
        }
  }
  return null;
};

// export const pwdMatcher = (control: AbstractControl): {[key: string]: boolean} => {
//   const pass = control.get('password');
//   const repass = control.get('repassword');
//   if (pass.value === repass.value) {
//     return null;
//   } else {
//     return { nomatch: true };
//   }
//   }
// //};
// // export class PasswordValidation {

    
// function MatchPassword(pass:string, repass:string): ValidatorFn {
//     return (control: AbstractControl): { [key: string]: boolean } | null => {
//         if(pass != repass) {
//             console.log('false');
//             control.get('repassword').setErrors( {MatchPassword: true} )
//         } else {
//             console.log('true');
//             return null
//         }
//         return null;
//     };
// }

    // function MatchPassword(pass:string, repass:string)
    // return (AC: AbstractControl) {
    //      console.log("password macthcinf: ");
    //    let password = AC.get('password').value; // to get value in input tag
    //    console.log("password: "+password);
    //    let confirmPassword = AC.get('repassword').value; // to get value in input tag
    //     if(password != confirmPassword) {
    //         console.log('false');
    //         AC.get('repassword').setErrors( {MatchPassword: true} )
    //     } else {
    //         console.log('true');
    //         return null
    //     }
    // }
//}