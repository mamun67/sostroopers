import { Component, OnInit, Inject } from '@angular/core';
import { NGORegisterService } from '../services/ngoregister/ngoregister.service';
import { PasswordValidation } from '../matchPwd/matchPwd.component';
import { FormGroup, Validators, FormControl, FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router} from '@angular/router';
// import * as $ from 'jquery';
declare var jquery: any;
declare var $: any; 
declare function myMethod():any;

@Component({
  selector: 'app-maps',
  templateUrl: './ngoreg.component.html',
  styleUrls: ['./ngoreg.component.css']
})
export class NGORegComponent implements OnInit {
  ngo: any;
  shelter: boolean;
  medical: boolean;
  serviceProvide: any;
  response: any;
  error: any;
  angForm: FormGroup;
  country:string;
  state:string;
  district:string;
  zipcode:string;
  other:string;
  AreaName:string;
  loader:boolean=false;
  resourcesForm: FormGroup;
  
  constructor(private activatedRoute: ActivatedRoute,private router:Router, @Inject(NGORegisterService) private ngoRegisterService: NGORegisterService, private fb: FormBuilder) {
    this.ngo = {};
    this.serviceProvide=[];
    this.country="-1";
    this.other="";
  }
  message:string="";
  errorpng:boolean=false;
  // branch:string="";
  // branches:any=[];
  ngoRegister() {
    console.log("here calling shelter......."+ this.shelter)
        this.ngo["Addr"]={
      "$class": "org.disaster.model.Address",
    "Country": this.country,
    "State": this.state,
    "District": this.district,
    "Zip_Code": this.zipcode,
    "Area": this.AreaName,
    "Other": this.other
  }
  // this.branches=[];
    if (this.shelter) {
      this.serviceProvide.push('Shelter');
    }
    if (this.medical) {
      this.serviceProvide.push('Medical');
    }

    // for(let i=0;i<this.branch.split(",").length;i++){
    //   this.branches.push(this.branch.split(",")[i]);
    // }

     for(var i=0; i<this.tempResourcesRequest.length;i++){
       delete this.tempResourcesRequest[i]["isEdit"];
     }
    this.ngo.ServicesProvide = this.serviceProvide;
    this.ngo.Status=true;
    this.ngo.Blacklist=false;
    this.ngo.Active_event=[];
    this.ngo.Past_Disaster=[];
    this.ngo["$class"] = "org.disaster.model.NGO";
    this.ngo["Status"] = true;
    this.ngo["Blacklist"] = false;
    this.ngo["Branches"] = this.tempResourcesRequest; 
    console.log("here calling servie.......")
      $(".overlay").show();
    this.ngoRegisterService.NGORegister(this.ngo).subscribe((data: any) => {
        $(".overlay").hide();
      this.response = data;
      this.message="Registered Successfully..! You may login now";
      this.errorpng=false;
       $("#messageModal").modal();
      
      //this.router.navigate(['./home']);
      console.log(data);
    }, error => {
       $(".overlay").hide();
      this.error = error // error path);
      this.message="Something went wrong..!!";
      this.errorpng=true;
       $("#messageModal").modal();
      // $("#messageModal").modal();
      console.log(this.error);
    }
    );
  }

  redirect(){
    this.router.navigate(['./home']);
  }

  //    this.angForm = this.formBuilder.group({
  // 	username: new FormControl('', Validators.required),
  // 	email: new FormControl('', Validators.compose([
  // 		Validators.required,
  // 		Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
  // 	]))
  // });
  ngOnInit() {
    myMethod();

    this.angForm = new FormGroup({
      name: new FormControl('', Validators.compose([
        Validators.required,
        Validators.maxLength(25),
        Validators.minLength(5),
        Validators.pattern('^[A-Za-z ]+$')
      ])),

      global: new FormControl('', Validators.compose([
        Validators.required,
        Validators.maxLength(10),
        Validators.minLength(4),
        Validators.pattern('^[0-9]+$')
      ])),

      admin: new FormControl('', Validators.compose([
        Validators.required,
        Validators.maxLength(25),
        Validators.minLength(5),
        Validators.pattern('^[A-Za-z ]+$')
      ])),

      email: new FormControl('', Validators.compose([
        Validators.required,
        Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
      ])),
          country: new FormControl('',Validators.compose([
        Validators.required,
        
      ])),
       state: new FormControl('',Validators.compose([
        Validators.required,
        
      ])),
       district: new FormControl('',Validators.compose([
        Validators.required,
        Validators.minLength(3),
        Validators.maxLength(25),
        Validators.pattern('^[a-zA-Z ]+$')
      ])),
       AreaName: new FormControl('',Validators.compose([
        Validators.required,
        Validators.minLength(3),
        Validators.maxLength(25),
        Validators.pattern('^[a-zA-Z0-9-/ ]+$')
      ])),
       other: new FormControl(''),
       zipcode:new FormControl('',Validators.compose([
        Validators.required,
        Validators.pattern('^[0-9]{6}$')
      ])),
      // branches: new FormControl('', Validators.compose([
      //   Validators.required,
      //   Validators.minLength(4),
      //   Validators.pattern('^[A-Za-z0-9, ]+$')
      // ])),

      phone: new FormControl('', Validators.compose([
        Validators.required,
        Validators.minLength(10),
        Validators.maxLength(10),
        Validators.pattern('^[0-9]+$')
        // Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
      ])),

      shelter: new FormControl(''),
      medical: new FormControl(''),
     
      pwd: new FormControl('',Validators.compose([
        Validators.required
      ])),
      repwd: new FormControl('',Validators.compose([
        PasswordValidation
        
      ])),
      address: new FormControl('')


    })


     this.resourcesForm = new FormGroup({
      branchname: new FormControl('', Validators.compose([
        Validators.required,  
        Validators.pattern('^[A-Za-z ]+$')
      ])),

      //  resourceCount: new FormControl('', Validators.compose([
      //   Validators.required,  
      //   Validators.pattern('^[0-9]+$')
      // ])),
      

      state: new FormControl('', Validators.compose([
        Validators.required,  
         Validators.pattern('^[A-Za-z ]+$')
      ])),


      country: new FormControl('', Validators.compose([
        Validators.required,  
         Validators.pattern('^[A-Za-z ]+$')
      ])),

        
       district: new FormControl('',Validators.compose([
        Validators.required,
        Validators.minLength(3),
        Validators.maxLength(25),
        Validators.pattern('^[a-zA-Z ]+$')
      ])),
       area: new FormControl('',Validators.compose([
        Validators.required,
        Validators.minLength(3),
        Validators.maxLength(25),
        Validators.pattern('^[a-zA-Z0-9-/ ]+$')
      ])),
       other: new FormControl(''),
       zipcode:new FormControl('',Validators.compose([
        Validators.required,
        Validators.pattern('^[0-9]{6}$')
      ])),
      
    })
  }

  account_validation_messages = {
    'name': [
      { type: 'required', message: 'Name is required' },
      { type: 'minlength', message: 'Name must be at least 5 characters long' },
      { type: 'maxlength', message: 'Name cannot be more than 25 characters long' },
      { type: 'pattern', message: 'Name must contain only letters' }
    ],

    'global': [
      { type: 'required', message: 'Global Id is required' },
      { type: 'minlength', message: 'Global Id must be at least 4 characters long' },
      { type: 'maxlength', message: 'Global Id cannot be more than 10 characters long' },
      { type: 'pattern', message: 'Global Id must contain only numbers' }
    ],

    'admin': [
      { type: 'required', message: 'Admin is required' },
      { type: 'minlength', message: 'Admin must be at least 4 characters long' },
      { type: 'maxlength', message: 'Admin cannot be more than 25 characters long' },
      { type: 'pattern', message: 'Admin must contain only letters' }
    ],

    'email': [
      { type: 'required', message: 'Email is required' },
      // { type: 'minlength', message: 'Email must be at least 4 characters long' },
      // { type: 'maxlength', message: 'Email cannot be more than 10 characters long' },
      { type: 'pattern', message: 'Please enter a valid email' }
    ],

      'country': [
      { type: 'required', message: 'Country is required' },
      { type: 'pattern', message: 'Please enter alphabets only' }
    
    ],
     'area': [
       { type: 'required', message: 'Area Name is required' },
      { type: 'minlength', message: 'Area Name must be at least 3 characters long' },
       { type: 'maxlength', message: 'Area Name cannot be more than 25 characters long' },
      { type: 'pattern', message: 'Please enter this a-zA-Z0-9-/ characters only' }
    
    ],

      'state': [
      { type: 'required', message: 'State is required' },
      { type: 'pattern', message: 'Please enter alphabets only' }
    
    ],
      'district': [
      { type: 'required', message: 'District is required' },
      { type: 'minlength', message: 'District must be at least 3 characters long' },
       { type: 'maxlength', message: 'District cannot be more than 25 characters long' },
      { type: 'pattern', message: 'Please enter alphabets only' }
    ],
      'AreaName': [
      { type: 'required', message: 'Area Name is required' },
      { type: 'minlength', message: 'Area Name must be at least 3 characters long' },
       { type: 'maxlength', message: 'Area Name cannot be more than 25 characters long' },
      { type: 'pattern', message: 'Please enter this a-zA-Z0-9-/ characters only' }
    ],
    'zipcode': [
      { type: 'required', message: 'ZipCode is required' },
 
      { type: 'pattern', message: 'Please enter 6 numbers only' }
    ],

    // 'branches': [
    //   { type: 'required', message: 'Branches is required' },
    //   { type: 'minlength', message: 'Email must be at least 4 characters long' },
    //   // { type: 'maxlength', message: 'Email cannot be more than 10 characters long' },
    //   { type: 'pattern', message: 'Branches must contain only letters and numbers' }
    // ],

      'pwd': [
      { type: 'required', message: 'Password is required' }
    ],
    'repwd': [
      { type: 'isError', message: 'Password & Confirm Password should match' }
    ],

    'phone': [
      { type: 'required', message: 'Mobile number is required' },
      { type: 'minlength', message: 'Mobile number must be at contain 10 characters long' },
      { type: 'maxlength', message: 'Mobile number must be at contain 10 characters long' },
      { type: 'pattern', message: 'Mobile number must contain only numbers' }
    ],

     
    'branchname': [
      { type: 'required', message: 'Branch name is required' },
      
      { type: 'pattern', message: 'Branch name must contain only letters' }
    ]

  

  }
tempResourcesRequest=[];
  addRow(){
     
     this.tempResourcesRequest.push({
        "$class": "org.disaster.model.Branches",
        "AreaName": "",
        "add":{
            "Country": "",
            "State": "",
            "District": "",
            "Area": "",
            "Other": "",
            "Zip_Code": ""
        },
        
        "isEdit":true
      })
  }

  isEdit:number=0;
 findCount(index){
   this.tempResourcesRequest[index].isEdit=false;
   this.isEdit=0;
   for(var i=0; i<this.tempResourcesRequest.length;i++){
     if(this.tempResourcesRequest[i].isEdit==false){
       this.isEdit=this.isEdit+1;
     }
    
   }
 }

 deleteResource(index){
   this.tempResourcesRequest.splice(index,1);
 }

}
