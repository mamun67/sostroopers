import { Component, OnInit, Inject} from '@angular/core';
import { ActivatedRoute, Router} from '@angular/router';
import { FormGroup, Validators, FormControl, FormBuilder } from '@angular/forms';
import { GetDisasterEventsService} from '../services/getdisasterevents/getdisasterevents.service';
import { GlobalService} from '../services/global/global.service';
import {LOCAL_STORAGE, WebStorageService} from 'angular-webstorage-service';
declare var jquery: any;
declare var $: any; 

declare function showTabsFunc():any;

@Component({
  selector: 'app-past-events',
  templateUrl: './pastEvents.component.html',
  styleUrls: ['./pastEvents.component.css']
})
export class PastEventsComponent implements OnInit {
  allDisasters:any;
  error:any;
  message:string="";
  errorpng:boolean;
  disasters:any={};
  helpNeeded:string="";
  showDiv:string="";
  availShelters:any=[];
   
 
  constructor(@Inject(LOCAL_STORAGE) private storage: WebStorageService,private globalService:GlobalService,private activatedRoute: ActivatedRoute,private router:Router,private getDisasterEvents:GetDisasterEventsService) {
    this.allDisasters=[];
    this.availShelters=[];
     this.getActiveEvents();
     //this.getDisastersByStatus();
  //this.getSheltersByNGOAndDisaster();
//     this.allDisasters=[
//   {
//     "$class": "org.disaster.model.Disaster_Event",
//     "Name":"Name Of Disaster",
//     "Event_Id": "0259",
//     "location": [{
//       "$class": "org.disaster.model.DisLocation",
//       "State": "Duis",
//       "Country": "Anim labore"
//     } ],
//     "Type_Of_Disaster": "Flood",
//     "AreaAffected": [
//       "Chennai",
//       "Sipcot"
//     ],
//     "Types_Of_Help_Needed": [
//       "Shelter",
//       "Volunteer"
//     ],
//     "status": "Active",
//     "siteAdmin": "resource:org.disaster.model.Site_Admin#6769",
//     "ngos": [
//        {
//     "$class": "org.disaster.model.NGO",
//     "GlobalId": "string",
//     "Name": "string",
//     "Admin": "string",
//     "Address": "string",
//     "NGO_Email": "string",
//     "Contact": "string",
//     "Branches": "string",
//     "ServicesProvide": [],
//     "event": []
//   },{
//     "$class": "org.disaster.model.NGO",
//     "GlobalId": "string",
//     "Name": "string",
//     "Admin": "string",
//     "Address": "string",
//     "NGO_Email": "string",
//     "Contact": "string",
//     "Branches": "string",
//     "ServicesProvide": [],
//     "event": []
//   },{
//     "$class": "org.disaster.model.NGO",
//     "GlobalId": "string",
//     "Name": "string",
//     "Admin": "string",
//     "Address": "string",
//     "NGO_Email": "string",
//     "Contact": "string",
//     "Branches": "string",
//     "ServicesProvide": [],
//     "event": []
//   },{
//     "$class": "org.disaster.model.NGO",
//     "GlobalId": "string",
//     "Name": "string",
//     "Admin": "string",
//     "Address": "string",
//     "NGO_Email": "string",
//     "Contact": "string",
//     "Branches": "string",
//     "ServicesProvide": [],
//     "event": []
//   }
//     ]
//   },{
//     "$class": "org.disaster.model.Disaster_Event",
//     "Event_Id": "0259",
//     "Name":"Name Of Disaster",
//     "location": [{
//       "$class": "org.disaster.model.DisLocation",
//       "State": "Duis",
//       "Country": "Anim labore"
//     } ],
//     "Type_Of_Disaster": "Flood",
//     "AreaAffected": [
//       "Chennai",
//       "Sipcot"
//     ],
//     "Types_Of_Help_Needed": [
//       "Shelter",
//       "Volunteer"
//     ],
//     "status": "Active",
//     "siteAdmin": "resource:org.disaster.model.Site_Admin#6769",
//     "ngos": [
//        {
//     "$class": "org.disaster.model.NGO",
//     "GlobalId": "string",
//     "Name": "string",
//     "Admin": "string",
//     "Address": "string",
//     "NGO_Email": "string",
//     "Contact": "string",
//     "Branches": "string",
//     "ServicesProvide": [],
//     "event": []
//   },{
//     "$class": "org.disaster.model.NGO",
//     "GlobalId": "string",
//     "Name": "string",
//     "Admin": "string",
//     "Address": "string",
//     "NGO_Email": "string",
//     "Contact": "string",
//     "Branches": "string",
//     "ServicesProvide": [],
//     "event": []
//   },{
//     "$class": "org.disaster.model.NGO",
//     "GlobalId": "string",
//     "Name": "string",
//     "Admin": "string",
//     "Address": "string",
//     "NGO_Email": "string",
//     "Contact": "string",
//     "Branches": "string",
//     "ServicesProvide": [],
//     "event": []
//   },{
//     "$class": "org.disaster.model.NGO",
//     "GlobalId": "string",
//     "Name": "string",
//     "Admin": "string",
//     "Address": "string",
//     "NGO_Email": "string",
//     "Contact": "string",
//     "Branches": "string",
//     "ServicesProvide": [],
//     "event": []
//   }
//     ]
//   },{
//     "$class": "org.disaster.model.Disaster_Event",
//     "Event_Id": "0259",
//     "Name":"Name Of Disaster",
//     "location": [{
//       "$class": "org.disaster.model.DisLocation",
//       "State": "Duis",
//       "Country": "Anim labore"
//     } ],
//     "Type_Of_Disaster": "Flood",
//     "AreaAffected": [
//       "Chennai",
//       "Sipcot"
//     ],
//     "Types_Of_Help_Needed": [
//       "Shelter",
//       "Volunteer"
//     ],
//     "status": "Active",
//     "siteAdmin": "resource:org.disaster.model.Site_Admin#6769",
//     "ngos": [
//        {
//     "$class": "org.disaster.model.NGO",
//     "GlobalId": "string",
//     "Name": "string",
//     "Admin": "string",
//     "Address": "string",
//     "NGO_Email": "string",
//     "Contact": "string",
//     "Branches": "string",
//     "ServicesProvide": [],
//     "event": []
//   },{
//     "$class": "org.disaster.model.NGO",
//     "GlobalId": "string",
//     "Name": "string",
//     "Admin": "string",
//     "Address": "string",
//     "NGO_Email": "string",
//     "Contact": "string",
//     "Branches": "string",
//     "ServicesProvide": [],
//     "event": []
//   },{
//     "$class": "org.disaster.model.NGO",
//     "GlobalId": "string",
//     "Name": "string",
//     "Admin": "string",
//     "Address": "string",
//     "NGO_Email": "string",
//     "Contact": "string",
//     "Branches": "string",
//     "ServicesProvide": [],
//     "event": []
//   },{
//     "$class": "org.disaster.model.NGO",
//     "GlobalId": "string",
//     "Name": "string",
//     "Admin": "string",
//     "Address": "string",
//     "NGO_Email": "string",
//     "Contact": "string",
//     "Branches": "string",
//     "ServicesProvide": [],
//     "event": []
//   }
//     ]
//   }
// ]


// this.availShelters=[
//   {
//     "$class": "org.disaster.model.Shelter",
//     "Shelter_Id": "Shelter1",
//     "Total_Capacity": 300,
//     "location": {
//       "$class": "org.disaster.model.Location",
//       "latitude": "21",
//       "longitude": "25"
//     },
//     "CurrentPeople": 0,
//     "Contact": "+0342-9087659",
//     "No_Of_doctors": 12,
//     "No_Of_Volunteer": 60,
//     "available_Equipment": [
//       {
//         "$class": "org.disaster.model.Available_Equipment",
//         "Equipment_Name": "xyz",
//         "Count": "10"
//       },
//       {
//         "$class": "org.disaster.model.Available_Equipment",
//         "Equipment_Name": "abc",
//         "Count": "12"
//       }
//     ],
//     "available_Amenities": [
//       {
//         "$class": "org.disaster.model.Available_Amenities",
//         "Amenities_Name": "cde",
//         "Count": "20"
//       }
//     ],
//     "resident": [
//       {
//         "$class": "org.disaster.model.ResidentUpdate",
//         "Name": "Suparna Roy",
//         "Father_Name": "Swapan Kumar Roy",
//         "DOB": "22 Mar 1993",
//         "Address": "Burdwan, Kolkata",
//         "Resident_Email": "suparnaroy@gmail.com",
//         "Contact": "7797549390",
//         "Biometric": "mIyo=",
//         "BloodGroup": "A+",
//         "shelter": []
//       }
//     ],
//     "ngo": "resource:org.disaster.model.NGO#8017"
//   },
//   {
//     "$class": "org.disaster.model.Shelter",
//     "Shelter_Id": "Shelter2",
//     "Total_Capacity": 300,
//     "location": {
//       "$class": "org.disaster.model.Location",
//       "latitude": "21",
//       "longitude": "25"
//     },
//     "CurrentPeople": 0,
//     "Contact": "+0342-9087659",
//     "No_Of_doctors": 12,
//     "No_Of_Volunteer": 60,
//     "available_Equipment": [
//       {
//         "$class": "org.disaster.model.Available_Equipment",
//         "Equipment_Name": "xyz",
//         "Count": "10"
//       },
//       {
//         "$class": "org.disaster.model.Available_Equipment",
//         "Equipment_Name": "abc",
//         "Count": "12"
//       }
//     ],
//     "available_Amenities": [
//       {
//         "$class": "org.disaster.model.Available_Amenities",
//         "Amenities_Name": "cde",
//         "Count": "20"
//       }
//     ],
//     "resident": [
//   {
//     "$class": "org.disaster.model.Resident",
//     "Name": "SK arfin",
//     "Father_Name": "asasas",
//     "DOB": "2018-08-05",
//     "Address": "KOL",
//     "Resident_Email": "sk.arfin@capgemini.com",
//     "Contact": "9090909090",
//     "Biometric": "D160A686FEAC8FFD95070E185A8735F14C5B9D7E",
//     "BloodGroup": "a-",
//     "shelter": []
//   },
//   {
//     "$class": "org.disaster.model.Resident",
//     "Name": "Spanadana Bola",
//     "Father_Name": "sdadas",
//     "DOB": "2017-07-05",
//     "Address": "sasAS",
//     "Resident_Email": "spanadana.bola@capgemini.com",
//     "Contact": "9492371909",
//     "Biometric": "8FDA5EECAC5CF9444548269ED33E7AC6D3A4E199",
//     "BloodGroup": "b+",
//     "shelter": []
//   },
//   {
//     "$class": "org.disaster.model.Resident",
//     "Name": "Suparna Roy",
//     "Father_Name": "Swapan Kumar Roy",
//     "DOB": "22 Mar 1993",
//     "Address": "Burdwan, Kolkata",
//     "Resident_Email": "suparnaroy@gmail.com",
//     "Contact": "7797549390",
//     "Biometric": "mIyo=",
//     "BloodGroup": "A+",
//     "shelter": [
//       {
//         "$class": "org.disaster.model.ShelterInfo",
//         "Status": "Moved",
//         "shelterId": "resource:org.disaster.model.Shelter#Shelter1"
//       }
//     ]
//   }
// ],
//     "ngo": "resource:org.disaster.model.NGO#8016"
//   }
// ]

  }


   getActiveEvents(){
     this.user=this.storage.get("user");
     this.allDisasters=[];
     for(let i=0;i<this.user.Past_Disaster.length;i++){
       console.log(this.user.Past_Disaster[i]);
       console.log("disaster here is:"+this.user.Past_Disaster[i].disasater);
          this.getAllDisasterEvents(this.user.Past_Disaster[i].disasater.split("#")[1]);
     }

  }

   getAllDisasterEvents(id){
    $(".overlay").show();
   
    this.getDisasterEvents.getDisasterById(id).subscribe((data: any) => {
       $(".overlay").hide();
      this.allDisasters.push(data);
      
        this.errorpng=false;
        
      console.log(data);
    }, error => {
      $(".overlay").hide();
     
      this.errorpng=true;
      
      this.message="Something went wrong.."
     // $("#showMessage").modal();
      console.log(error);
    }
    );
  }


  ngOnInit() {
  //   console.log("calling init")
  //  this.disasters={
  //   "$class": "org.disaster.model.Disaster_Event",
  //   "Name":"",
  //   "Event_Id": "",
  //   "location": [{
  //     "$class": "org.disaster.model.DisLocation",
  //     "State": "",
  //     "Country": ""
  //   } ],
  //   "Type_Of_Disaster": "",
  //   "AreaAffected": [
     
  //   ],
  //   "Types_Of_Help_Needed": [
     
  //   ],
  //   "status": ""
  
  //  }

  //  this.shelter= {
  //   "$class": "org.disaster.model.Shelter",
  //   "Shelter_Id": "Shelter1",
  //   "Total_Capacity": 300,
  //   "location": {
  //     "$class": "org.disaster.model.Location",
  //     "latitude": "21",
  //     "longitude": "25"
  //   },
  //   "CurrentPeople": 0,
  //   "Contact": "+0342-9087659",
  //   "No_Of_doctors": 12,
  //   "No_Of_Volunteer": 60,
  //   "available_Amenities": [
  //   ],
  //   "resident": [
  //   ],
  //   "ngo": "resource:org.disaster.model.NGO#8017"
  // }

this.availShelters=[
  {
    "$class": "org.disaster.model.Shelter",
    "Shelter_Id": "Shelter1",
    "Total_Capacity": 300,
    "location": {
      "$class": "org.disaster.model.Location",
      "latitude": "21",
      "longititude": "25"
    },
    "CurrentPeople": 0,
    "Contact": "+0342-9087659",
    "No_Of_doctors": 12,
    "No_Of_Volunteer": 60,
    "available_Equipment": [
      {
        "$class": "org.disaster.model.Available_Equipment",
        "Equipment_Name": "xyz",
        "Count": "10"
      },
      {
        "$class": "org.disaster.model.Available_Equipment",
        "Equipment_Name": "abc",
        "Count": "12"
      }
    ],
    "available_Amenities": [
      {
        "$class": "org.disaster.model.Available_Amenities",
        "Amenities_Name": "cde",
        "Count": "20"
      }
    ],
    "resident": [
      {
        "$class": "org.disaster.model.ResidentUpdate",
        "Name": "Suparna Roy",
        "Father_Name": "Swapan Kumar Roy",
        "DOB": "22 Mar 1993",
        "Address": "Burdwan, Kolkata",
        "Resident_Email": "suparnaroy@gmail.com",
        "Contact": "7797549390",
        "Biometric": "mIyo=",
        "BloodGroup": "A+",
        "shelter": []
      }
    ],
    "ngo": "resource:org.disaster.model.NGO#8017"
  },
  {
    "$class": "org.disaster.model.Shelter",
    "Shelter_Id": "Shelter2",
    "Total_Capacity": 300,
    "location": {
      "$class": "org.disaster.model.Location",
      "latitude": "21",
      "longititude": "25"
    },
    "CurrentPeople": 0,
    "Contact": "+0342-9087659",
    "No_Of_doctors": 12,
    "No_Of_Volunteer": 60,
    "available_Equipment": [
      {
        "$class": "org.disaster.model.Available_Equipment",
        "Equipment_Name": "xyz",
        "Count": "10"
      },
      {
        "$class": "org.disaster.model.Available_Equipment",
        "Equipment_Name": "abc",
        "Count": "12"
      }
    ],
    "available_Amenities": [
      {
        "$class": "org.disaster.model.Available_Amenities",
        "Amenities_Name": "cde",
        "Count": "20"
      }
    ],
    "resident": [
  {
    "$class": "org.disaster.model.Resident",
    "Name": "SK arfin",
    "Father_Name": "asasas",
    "DOB": "2018-08-05",
    "Address": "KOL",
    "Resident_Email": "sk.arfin@capgemini.com",
    "Contact": "9090909090",
    "Biometric": "D160A686FEAC8FFD95070E185A8735F14C5B9D7E",
    "BloodGroup": "a-",
    "shelter": []
  },
  {
    "$class": "org.disaster.model.Resident",
    "Name": "Spanadana Bola",
    "Father_Name": "sdadas",
    "DOB": "2017-07-05",
    "Address": "sasAS",
    "Resident_Email": "spanadana.bola@capgemini.com",
    "Contact": "9492371909",
    "Biometric": "8FDA5EECAC5CF9444548269ED33E7AC6D3A4E199",
    "BloodGroup": "b+",
    "shelter": []
  },
  {
    "$class": "org.disaster.model.Resident",
    "Name": "Suparna Roy",
    "Father_Name": "Swapan Kumar Roy",
    "DOB": "22 Mar 1993",
    "Address": "Burdwan, Kolkata",
    "Resident_Email": "suparnaroy@gmail.com",
    "Contact": "7797549390",
    "Biometric": "mIyo=",
    "BloodGroup": "A+",
    "shelter": [
      {
        "$class": "org.disaster.model.ShelterInfo",
        "Status": "Moved",
        "shelterId": "resource:org.disaster.model.Shelter#Shelter1"
      }
    ]
  }
],
    "ngo": "resource:org.disaster.model.NGO#8016"
  }
]

 this.disasters={
    "$class": "org.disaster.model.Disaster_Event",
    "Name":"",
    "Event_Id": "",
    "location": [{
      "$class": "org.disaster.model.DisLocation",
      "State": "",
      "Country": ""
    } ],
    "Type_Of_Disaster": "",
    "AreaAffected": [
     
    ],
    "Types_Of_Help_Needed": [
     
    ],
    "status": ""
  
   }

   this.shelter= {
    "$class": "org.disaster.model.Shelter",
    "Shelter_Id": "Shelter1",
    "Total_Capacity": 300,
    "location": {
      "$class": "org.disaster.model.Location",
      "latitude": "21",
      "longitude": "25"
    },
    "CurrentPeople": 0,
    "Contact": "+0342-9087659",
    "No_Of_doctors": 12,
    "No_Of_Volunteer": 60,
    "available_Amenities": [
    ],
    "resident": [
    ],
    "ngo": "resource:org.disaster.model.NGO#8017"
  }

  
  
}

 openModal(value){
  this.showDiv=value;
 }
 shelter:any={};
 newShelt:any={};
 shelterInfo=false;



 

 showShelter(shelt){
   this.shelter=shelt;
   $("#showShelter").modal();
 }
 showtabs:boolean=false;
//  showloader:boolean=false;
   showModal(disaster){
      this.showtabs=true;
     this.helpNeeded="";
     this.disasters=disaster;
     if(this.disasters.Types_Of_Help_Needed.length!=0){
       this.helpNeeded=this.disasters.Types_Of_Help_Needed[0];
     }
     
     for(let index=1; index<this.disasters.Types_Of_Help_Needed.length; index++){
       this.helpNeeded=this.helpNeeded+","+this.disasters.Types_Of_Help_Needed[index];
     }
     this.availShelters=[];
     this.shelterInfo=false;
    this.getSheltersByNGOAndDisaster();
     //$("#showmodal").modal();
    //  this.showloader=true;
     setTimeout(() => {
      // this.showloader = false;
         $("#defaultOpen").click();
       // document.getElementById("defaultOpen").click();
    }, 3)
       //$("#onshow").click();
    //  console.log

   }



   user:any={};
   loader:boolean=false;
 getSheltersByNGOAndDisaster() {
   this.errorpng=false;
   this.user=this.storage.get("user");
   this.availShelters=[];
  $(".overlay").show();
    console.log("here calling servie.......")
    this.getDisasterEvents.getShelterByDisasterAndNGO(this.disasters.EventName,this.user.NGO_Email).subscribe((data: any) => {

      this.availShelters = data;
         $(".overlay").hide();
        //this.message="More than one person found.. Please enter unique details.."
          this.errorpng=false;
        this.loader=false;
      
      console.log(data);
    }, error => {
      this.error = error // error path);
      this.availShelters =[];
      $(".overlay").hide();
      this.errorpng=true;
      this.message="Something went wrong.."
      console.log(this.error);
    }
    );
  }

    getDisastersByStatus() {
      this.user=this.storage.get("user");
      this.allDisasters = [];
   $(".overlay").show();
   this.errorpng=false;
    console.log("here calling servie.......")
    this.getDisasterEvents.getDisasterByStatus(false).subscribe((data: any) => {
       $(".overlay").hide();
      for(let i=0;i<data.length;i++){
          for(let j=0;j<data[i].ngos.length;j++){
            if(data[i].ngos[i].ngo==this.user.NGO_Email){
              this.allDisasters.push(data[i]);
            }
          }
      }
      //$(".overlay").hide();
        //this.message="More than one person found.. Please enter unique details.."
          this.errorpng=false;
        
      
      console.log(data);
    }, error => {
     // error path);
    this.allDisasters=[];
      this.errorpng=true;
       $(".overlay").hide();
      this.message="Something went wrong.."
      console.log(error);
    }
    );
  }

  


}
