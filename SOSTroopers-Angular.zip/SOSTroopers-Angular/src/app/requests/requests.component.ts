import { Component, OnInit, Inject } from '@angular/core';
import { ActivatedRoute, Router} from '@angular/router';
import { FormGroup, Validators, FormControl, FormBuilder } from '@angular/forms';
import { GetDisasterEventsService} from '../services/getdisasterevents/getdisasterevents.service';
import { RequestsService} from '../services/requests/requests.service';
import {LOCAL_STORAGE, WebStorageService} from 'angular-webstorage-service';

declare var jquery: any;
declare var $: any; 

declare function showTabsFunc():any;

@Component({
  selector: 'app-requests',
  templateUrl: './requests.component.html',
  styleUrls: ['./requests.component.css']
})
export class RequestsComponent implements OnInit {
  allRequests:any=[];
  error:any;
  message:string="";
  errorpng:boolean;
  request:any={};
  showDiv:string="";
  availShelters:any=[];
  commentDesc:string="";
  status:string="";
   
 
  constructor(@Inject(LOCAL_STORAGE) private storage: WebStorageService,private requestsService:RequestsService,private activatedRoute: ActivatedRoute,private router:Router,private getDisasterEvents:GetDisasterEventsService) {
    this.allRequests=[];
    this.status="";
    this.request={
      "request_status":""
    }
    this.getAllRequests();
  //   this.allRequests=[{
  //   "$class": "org.disaster.model.RaiseRequest",
  //   "request_Id": "string",
  //   "Amenitiesname": "string",
  //   "count": "string",
  //   "comments": [{
  //     "$class": "org.disaster.model.DisLocation",
  //     "Discription": "Duis",
  //     "Timestamp": "Mon Sep 10 2018 08:56:40 GMT-0700"
  //   } ],
  //   "request_status": "Open",
  //   "date": "2018-09-17T03:56:28.241Z",
  //   "disaster_name": "string#jgjas",
  //   "shelter": "string#jgjas",
  //   "ngo": "string#jgjas"
  // }]
 }

  ngOnInit() {
    console.log("calling init")
  //  this.request={
  //   "$class": "org.disaster.model.RaiseRequest",
  //   "request_Id": "string",
  //   "Amenitiesname": "string",
  //   "count": "string",
  //   "comments": [],
  //   "request_status": "Open",
  //   "date": "2018-09-17T03:56:28.241Z",
  //   "disaster_name": "string#jgjas",
  //   "shelter": "string#jgjas",
  //   "ngo": "string#jgjas"
  // }

  }
 openModal(value){
  this.showDiv=value;
 }
 shelter:any={};
 newShelt:any={};
 shelterInfo=false;



 

 showShelter(shelt){
   this.shelter=shelt;
   $("#showShelter").modal();
 }
 showtabs:boolean=false;
//  showloader:boolean=false;
   showModal(request){
      this.showtabs=true;
    
     this.request=request;
    
     setTimeout(() => {
      
         $("#defaultOpen").click();
      
    }, 3)
   }



   
loader:boolean=false;
    getAllRequests() {
   this.errorpng=false;
    $(".overlay").show();
    console.log("here calling servie.......")
    this.requestsService.getAllNGORequests(this.storage.get("user").NGO_Email).subscribe((data: any) => {

    this.allRequests = data;
      $(".overlay").hide();
        //this.message="More than one person found.. Please enter unique details.."
          this.errorpng=false;
        
      
      console.log(data);
    }, error => {
      this.error = error // error path);
      $(".overlay").hide();
      this.errorpng=true;
      this.allRequests=[];
      this.message="Something went wrong.."
      $("#messageModal").modal();
      console.log(this.error);
    }
    );
  }

  cancelRequest(request){
    this.request=request;
    var temp=this.request.request_status;
    this.request.request_status="Cancelled";

    this.errorpng=false;
   $(".overlay").show();

    console.log("here calling servie.......")
    this.requestsService.updateRequests(this.request).subscribe((data: any) => {

      
     $(".overlay").hide();
        //this.message="More than one person found.. Please enter unique details.."
          this.errorpng=false;
          
        
      
      console.log(data);
    }, error => {
      this.error = error // error path);
     $(".overlay").hide();
      this.errorpng=true;
      this.request.request_status=temp;
     
      this.message="Something went wrong..";
      $("#messageModal").modal();
      console.log(this.error);
    }
    );

 

  }

requestFail:boolean=false;

  addComment(){
    
    var date=new Date().toUTCString();
    this.request.comments.push({
      "$class": "org.disaster.model.comment",
      "Desc": this.commentDesc,
      "Date": date
    } )

  this.commentDesc='';

  this.errorpng=false;
   $(".overlay").show();
this.requestFail=false;
    console.log("here calling servie.......")
    this.requestsService.updateRequests(this.request).subscribe((data: any) => {

      
       $(".overlay").hide();
        //this.message="More than one person found.. Please enter unique details.."
          this.errorpng=false;
          this.requestFail=false;
        
      
      console.log(data);
    }, error => {
      this.error = error // error path);
      $(".overlay").hide();
      this.errorpng=true;
      this.requestFail=true;
      this.request.comments.splice(this.request.comments.length-1,1);
      this.message="Something went wrong.."
      console.log(this.error);
    }
    );

 
  }
 

  


}
