import { Component, OnInit,Inject } from '@angular/core';
import { ActivatedRoute, Router} from '@angular/router';
import { GetAllNGOsService } from '../services/getallngos/getallngos.service';
import {LOCAL_STORAGE, WebStorageService} from 'angular-webstorage-service';
import { FormGroup, Validators, FormControl, FormBuilder } from '@angular/forms';
import { LoginService } from  '../services/login/login.service';
declare var jquery: any;
declare var $: any; 
declare function showTabsFunc():any;

@Component({
  selector: 'app-respond',
  templateUrl: './respond.component.html',
  styleUrls: ['./respond.component.css']
})
export class RespondComponent implements OnInit {
  allNGOs:any;
  error:any;
  message:string="";
  errorpng:boolean;
    angForm1: FormGroup;
  user:any={};
disasterRespond:boolean=false;
showLogin:boolean=false;
usernew:any={}
  login:boolean=false;
  loginFail:boolean=false;
  sub;
  disasterName:string="";
  ngoName:string="";
  constructor(private  loginService:  LoginService,@Inject(LOCAL_STORAGE) private storage: WebStorageService,private activatedRoute: ActivatedRoute,private router:Router,private getallngos:GetAllNGOsService) {
  // this.getAllNGOs() ;
        this.login=this.storage.get("login");
        this.user=this.storage.get("user");
        if($.isEmptyObject(this.user)){
          this.user={
            "Role":""
          }
        }

        
  }

  ngOnInit() {
    console.log("calling init")

    this.angForm1 = new FormGroup({

       username: new FormControl('',Validators.compose([
        Validators.required,
         Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
      ])),
      password: new FormControl('',Validators.compose([
        Validators.required
      ]))
     

  })
   this.sub = this.activatedRoute.queryParams
                    .subscribe(params => { 
                     this.disasterName = params['EventID'];
                     this.usernew.username = params['NGOId'];
                     this.ngoName=params['NGOId'];
                     console.log('Query params ',this.disasterName+" "+this.usernew.username) });

                     if(this.login==true && this.user.NGO_Email==this.ngoName.trim()){
                       this.showLogin=false;
                       this.disasterRespond=false;
                        this.respondToDisaster();
                     }
                     else {
                       this.showLogin=true;
                       this.disasterRespond=false;
      
                     }
   }

   account_validation_messages = {
    
     'username': [
      { type: 'required', message: 'username is required' },
     { type: 'pattern', message: 'Please enter valid email' }
    ],

     'password': [
      { type: 'required', message: 'Confirm Password is required' }
    ]

 }


   userLogin(){
  //  this.login=true;
  
  var newUse={
  "$class": "org.disaster.model.verifyUser",
  "UserName": this.usernew.username,
  "Password": this.usernew.password,
  "Role": "NGO"
  
}
 this.disasterRespond=false;
 
  $(".overlay").show();
   console.log("calling here login function: "+ this.login);
    this.loginService.login(newUse).subscribe((data: any) => {
          this.loginFail=false;
          
          $(".overlay").hide();
           if(typeof(data["body"])==typeof("hello")){
              this.loginFail=true;
            this.storage.set("login", false);
           this.storage.set("user", {});
             
            this.login=false;
            this.angForm1.reset();
           }else{
         this.login=true;
          this.user=data["body"];
           this.user["Role"]="ngo";
          // this.globalService.setUser(this.user);
          this.storage.set("login", true);
           this.storage.set("user", this.user);
          this.angForm1.reset();
          location.reload(true);
          this.respondToDisaster();
           }
        //this.login  =  data;
        
        console.log(data);
      }, error => {
        this.error = error // error path);
        $(".overlay").hide();
            this.loginFail=true;
            this.storage.set("login", false);
           this.storage.set("user", {});
             
            this.login=false;
            this.angForm1.reset();
       //this.login=false;
       console.log(this.error);
      }
    );
 
 }

 respondToDisaster(){
   var body={
  "$class": "org.disaster.model.RespondToDisasater",
  "ngo": this.ngoName,
  "disasterEventId": this.disasterName
}
    this.disasterRespond=false;
   this.errorpng=false;
   this.getallngos.respondToDisaster(body).subscribe((data: any) => {
          
          $(".overlay").hide();
           this.disasterRespond=true;
           this.errorpng=false;
        console.log(data);
      }, error => {
        this.error = error // error path);
        $(".overlay").hide();
        this.disasterRespond=false;
        this.errorpng=true;
       console.log(this.error);
      }
    );
 
 }
 
}
