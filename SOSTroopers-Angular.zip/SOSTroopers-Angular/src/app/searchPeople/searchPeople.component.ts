import { Component, OnInit, Inject } from '@angular/core';
import { SearchpeopleService } from '../services/searchpeople/searchpeople.service';
import { FormGroup, Validators, FormControl, FormBuilder } from '@angular/forms';
declare var jquery: any;
declare var $: any;
@Component({
  selector: 'app-search',
  templateUrl: './searchPeople.component.html',
  styleUrls: ['./searchPeople.component.css']
})
export class PeopleSearchComponent implements OnInit {
  user: any;
  userf: any;
  response: any;
  error: any;
  angForm: FormGroup;
  showdiv:boolean;
  message:string;
  errorpng:boolean;
  constructor( @Inject(SearchpeopleService) private searchpeopleService: SearchpeopleService, private fb: FormBuilder) {
    this.user = {};
    this.userf = {};
    this.userf.fname="";
    this.userf.lname="";
    this.showdiv=false;
  //   this.user={
  //   "$class": "org.disaster.model.Resident",
  //   "Name": "Swati",
  //   "Father_Name": "Harendra",
  //   "DOB": "01 Nov 1993",
  //   "Address": "Bihar",
  //   "Resident_Email": "des@gmail.com",
  //   "Contact": "746874612",
  //   "Biometric": "vBIyPO=",
  //   "BloodGroup": "O+",
  //   "shelter": []
  // }
  }
 loader:boolean=false;
hashValue:string='';
 searchPeople() {
     $(".overlay").show();
    console.log("here calling servie...search....")
    this.searchpeopleService.searchPeople(this.userf).subscribe((data: any) => {
      
      this.response = data;
       $(".overlay").hide();
      if(data.length==0){
          this.message="Person not found with this details..!!"
          this.errorpng=false;
          this.showdiv=false;
      }
      // else if(data.length>1){
      //   this.message="More than one person found.. Please enter unique details.."
      //     this.errorpng=false;
      //   this.showdiv=false;
      // }
      else{
        this.errorpng=false;
        this.user=this.response
        this.showdiv=true;
      }
      console.log(data);
    }, error => {
      
       $(".overlay").hide();
      this.error = error // error path);
      this.showdiv=false;
      this.errorpng=true;
      this.message="Something went wrong.."
      console.log(this.error);
    }
    );
  }

  searchByBiometric(){
     console.log("here calling servie....bio...")
    $('#biometricModal').modal();
        
    setTimeout(() => {
      this.hashValue="8AD53424AEBB63295673BC782EF12FD6C71ABADB";
      $('#biometricModal').modal('hide');
      this.searchPeopleByBiometric(this.hashValue);
    }, 3000)
  }

  searchPeopleByBiometric(hashValue) {
     $(".overlay").show();
    console.log("here calling servie.......")
    this.searchpeopleService.searchPeopleByBiometric(hashValue).subscribe((data: any) => {
      
      this.response = data;
      $(".overlay").hide();
      if(data.length==0){
          this.message="Person not found with this details..!!"
          this.errorpng=false;
          this.showdiv=false;
      }
   
      else{
        this.errorpng=false;
        this.user=this.response
        this.showdiv=true;
      }
      console.log(data);
    }, error => {
      
      this.error = error // error path);
       $(".overlay").hide();
      this.showdiv=false;
      this.errorpng=true;
      this.message="Something went wrong.."
      console.log(this.error);
    }
    );
  }


  ngOnInit() {

    this.angForm = new FormGroup({
      fname: new FormControl('', Validators.compose([
        Validators.maxLength(25),
        Validators.pattern('^[A-Za-z ]+$')
      ])),

      lname: new FormControl('', Validators.compose([
        Validators.maxLength(25),
        Validators.pattern('^[A-Za-z ]+$')
      ]))

     
  
    })
  }

  account_validation_messages = {
    'fname': [
      { type: 'maxlength', message: 'First Name cannot be more than 25 characters long' },
      { type: 'pattern', message: 'First Name must contain only letters' }
    ],

     'lname': [
      { type: 'maxlength', message: 'Last Name cannot be more than 25 characters long' },
      { type: 'pattern', message: 'Last Name must contain only letters' }
    ]
  }

}
