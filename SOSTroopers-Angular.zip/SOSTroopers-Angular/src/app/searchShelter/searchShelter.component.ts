import { Component, OnInit, Inject } from '@angular/core';
import { ActivatedRoute, Router} from '@angular/router';
import { GlobalService} from '../services/global/global.service';
import { GetDisasterEventsService} from '../services/getdisasterevents/getdisasterevents.service';
import { GetShelterByDisasterService} from '../services/getShelterByDisaster/getShelterByDisaster.service';
declare var jquery: any;
declare var $: any; 
declare function showTabsFunc():any;

@Component({
  selector: 'app-search-shelter',
  templateUrl: './searchShelter.component.html',
  styleUrls: ['./searchShelter.component.css']
})
export class SearchShelterComponent implements OnInit {
  availShelters:any;
  disasterEvent:any;
  showtabs:boolean=false;
  loader:boolean=false;
  disaster:any={};
  disasters:any=[];
  errorpng:boolean=false;
  message:string="";
  // sub;
  constructor(@Inject(GetShelterByDisasterService) private getShelterByDisasterService: GetShelterByDisasterService,private globalService: GlobalService,@Inject(GetDisasterEventsService) private getDisasterEventsService: GetDisasterEventsService,private activatedRoute: ActivatedRoute,private router:Router) {

    this.availShelters=[];
    //  this.showtabs=false;
    //  this.errorpng=false;
   this.disasterEvent=this.globalService.getDisasterId();
   this.disaster=this.globalService.getDisaster();
  //  this.disasterEvent=1;
   if(this.disasterEvent==0){
     this.getAllDisasterEvents();
   }else{
       this.getAllShelters(this.disaster.EventName);//this.disaster.EventName);
   }
    console.log("disaster Id in search constructor: "+this.globalService.getDisasterId());
  
      }

  getAllDisasterEvents(){
    console.log("callign get all disasters.......");
     $(".overlay").show();
    this.getDisasterEventsService.GetDisasterEvents().subscribe((data: any) => {
       $(".overlay").hide();
      this.disasters=data["Events"];
     console.log("success block");
        this.errorpng=false;
        
      console.log(data);
    }, error => {
       $(".overlay").hide();
      this.errorpng=true;
      console.log("failed block");
      this.disasters=[];
      this.message="Something went wrong.."
      console.log(error);
    }
    );
  }

  getAllShelters(disasterName){
    //this.availShelters=[];
    this.loader=true;
    console.log("callign get all shelters.......");
    $(".overlay").show();
    this.getShelterByDisasterService.getShelterByDisaster(disasterName).subscribe((data: any) => {
      $(".overlay").hide();
      this.availShelters=data["Events"];
     
        this.errorpng=false;
        this.loader=false;
        
      console.log(data);
    }, error => {
       $(".overlay").hide();
       this.availShelters=[];
      this.errorpng=true;
      this.loader=false;
      this.message="Something went wrong.."
      console.log(error);
    }
    );
  }

  ngOnInit() {
    console.log("calling init")
    this.showtabs=false;
    
    // this.sub = this.activatedRoute.queryParams
    //                 .subscribe(params => { 
    //                  this.disasterEvent = +params['disasterEvent']||0;
    //                  console.log('Query params ',this.disasterEvent) });
   }
shelter:any={};
showDiv:string=""
   showModal(shelter){
     this.shelter=shelter;
     this.showtabs=true;
      setTimeout(() => {
      // this.showloader = false;
         $("#defaultOpen2").click();
       // document.getElementById("defaultOpen").click();
    }, 3)
     
    // $("#showmodal").modal();
   }

   openModal(value){
     this.showDiv=value;
   }
   onItemChange(value){
  
   console.log("calling here itemChange function: ")
   this.disasterEvent=parseInt(value)+1;
   this.globalService.setDisasterId(this.disasterEvent);
   this.globalService.setDisaster(this.disasters[value]);
   this.disaster=this.disasters[value];
   this.getAllShelters(this.disaster.EventName);
  //  this.getAllShelters(this.disaster.Name);
     console.log("disaster Id in search onItemChange: ");
     console.log(this.globalService.getDisasterId());
  
 
 }
 
}
