import { Injectable } from '@angular/core';
import { HttpClient,HttpErrorResponse} from  '@angular/common/http';

import { HttpHeaders } from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json'
  })
};


@Injectable({
  providedIn: 'root'
})
export class AddShelterService {

   API_URL  =  "";
 constructor(private  httpClient:  HttpClient) {}
 addEnlistedPeople(user){
   this.API_URL="https://disaster-business-network-blockchain-dda8f00fb8745b9c1e48.mybluemix.net/api/Enlisted_Affected_People_In_Particular_Shelter";
    return  this.httpClient.post(`${this.API_URL}`,user,httpOptions);
}

 changeShelter(user){
   this.API_URL="https://disaster-business-network-blockchain-dda8f00fb8745b9c1e48.mybluemix.net/api/changeshelterstatus";
    return  this.httpClient.post(`${this.API_URL}`,user,httpOptions);
}

updateResidentShelterByEmail(user){
   this.API_URL="https://disaster-business-network-blockchain-dda8f00fb8745b9c1e48.mybluemix.net/api/UpdateResidentInShelterByEmail";
    return  this.httpClient.post(`${this.API_URL}`,user,httpOptions);
}
deleteResidentInfo(user){
   this.API_URL="https://disaster-business-network-blockchain-dda8f00fb8745b9c1e48.mybluemix.net/api/deleteresidentinfo";
    return  this.httpClient.post(`${this.API_URL}`,user,httpOptions);
}
}
