import { Injectable } from '@angular/core';
import { HttpClient,HttpErrorResponse} from  '@angular/common/http';

import { HttpHeaders } from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json'
  })
};

@Injectable({
  providedIn: 'root'
})
export class CreateDisasterService {
 API_URL:string='';
 constructor(private  httpClient:  HttpClient) {}
 createDisaster(event){
   this.API_URL  =  "https://disaster-business-network-blockchain-dda8f00fb8745b9c1e48.mybluemix.net/api/Disaster_Event";
    return  this.httpClient.post(`${this.API_URL}`,event,httpOptions);
}

updateDisaster(event){
  this.API_URL  =  "https://disaster-business-network-blockchain-dda8f00fb8745b9c1e48.mybluemix.net/api/Disaster_Event/"+event.EventName;
    return  this.httpClient.put(`${this.API_URL}`,event,httpOptions);
}

 sendNotify(body){
   this.API_URL  =  "https://service.us.apiconnect.ibmcloud.com/gws/apigateway/api/d72617952b6f833daed5f62c7bc04a4d0355d4ee01a6f56fa4196b262b66b87a/getNonBlackLIstedEmai/getNonBlackLIstedEmail";
    return  this.httpClient.post(`${this.API_URL}`,body,httpOptions);
}
 
}
