import { Injectable } from '@angular/core';
import { HttpClient,HttpErrorResponse} from  '@angular/common/http';

import { HttpHeaders } from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json'
  })
};

@Injectable({
  providedIn: 'root'
})
export class CreateShelterService {
 API_URL:string='';
 constructor(private  httpClient:  HttpClient) {}
 createShelter(shelter){
   this.API_URL  =  "https://disaster-business-network-blockchain-dda8f00fb8745b9c1e48.mybluemix.net/api/Shelter";
    return  this.httpClient.post(`${this.API_URL}`,shelter,httpOptions);
}

getShelterByNGODisaster(disasterName,ngoName){
  this.API_URL  =  "https://disaster-business-network-blockchain-dda8f00fb8745b9c1e48.mybluemix.net/api/queries/select_shelter_by_NGO_Disasterevent?event="+disasterName+"&NGOName="+ngoName;
    return  this.httpClient.get(`${this.API_URL}`,httpOptions);
}

updateShelter(shelter){
  this.API_URL  =  "https://disaster-business-network-blockchain-dda8f00fb8745b9c1e48.mybluemix.net/api/Shelter/"+shelter.Shelter_Id;
    return  this.httpClient.put(`${this.API_URL}`,shelter,httpOptions);
}

 getShelter(shelter){
   this.API_URL  =  "https://disaster-business-network-blockchain-dda8f00fb8745b9c1e48.mybluemix.net/api/Shelter/"+shelter;
    return  this.httpClient.get(`${this.API_URL}`,httpOptions);
}
 
}
