import { Injectable } from '@angular/core';
import { HttpClient,HttpErrorResponse} from  '@angular/common/http';

import { HttpHeaders } from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json'
  })
};

@Injectable({
  providedIn: 'root'
})
export class GetShelterByDisasterService {
  API_URL:string;
 constructor(private  httpClient:  HttpClient) {}
 getShelterByDisaster(disasterName){
   
    this.API_URL  = "https://service.us.apiconnect.ibmcloud.com/gws/apigateway/api/d72617952b6f833daed5f62c7bc04a4d0355d4ee01a6f56fa4196b262b66b87a/d087e73a-61ee-45b3-9102-21f832f4e48e/getSelectShelterByDisasterEvent?event="+disasterName;
    //"https://disaster-business-network-blockchain-dda8f00fb8745b9c1e48.mybluemix.net/api/queries/select_shelter_by_Disasterevent?event="+disasterName;
    //"https://service.us.apiconnect.ibmcloud.com/gws/apigateway/api/d72617952b6f833daed5f62c7bc04a4d0355d4ee01a6f56fa4196b262b66b87a/d087e73a-61ee-45b3-9102-21f832f4e48e/getSelectShelterByDisasterEvent?event="+disasterName
    return  this.httpClient.get(`${this.API_URL}`,httpOptions);
}

}
