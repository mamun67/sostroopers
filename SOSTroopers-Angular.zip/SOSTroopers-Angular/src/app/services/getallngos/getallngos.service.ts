import { Injectable } from '@angular/core';
import { HttpClient,HttpErrorResponse} from  '@angular/common/http';

import { HttpHeaders } from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json'
  })
};

@Injectable({
  providedIn: 'root'
})
export class GetAllNGOsService {
  API_URL:string;
 constructor(private  httpClient:  HttpClient) {}
 getAllNGOs(){
    this.API_URL  =  "https://service.us.apiconnect.ibmcloud.com/gws/apigateway/api/d72617952b6f833daed5f62c7bc04a4d0355d4ee01a6f56fa4196b262b66b87a/49e15eb0-7d16-4eb5-868d-d07d55bc3087/getAllNgos"
    return  this.httpClient.get(`${this.API_URL}`,httpOptions);
}

 updateNGO(ngo){
    this.API_URL  =  "https://disaster-business-network-blockchain-dda8f00fb8745b9c1e48.mybluemix.net/api/NGO/"+ngo.NGO_Email;
    return  this.httpClient.put(`${this.API_URL}`,ngo,httpOptions);
}

 ngoBackoff(ngo){
    this.API_URL  =  "https://disaster-business-network-blockchain-dda8f00fb8745b9c1e48.mybluemix.net/api/NgoBackOff"
    return  this.httpClient.post(`${this.API_URL}`,ngo,httpOptions);
}

 getNGO(ngo){
    this.API_URL  =  "https://disaster-business-network-blockchain-dda8f00fb8745b9c1e48.mybluemix.net/api/NGO/"+ngo
    return  this.httpClient.get(`${this.API_URL}`,httpOptions);
}

respondToDisaster(ngo){
    this.API_URL  =  "https://disaster-business-network-blockchain-dda8f00fb8745b9c1e48.mybluemix.net/api/RespondToDisasater";
    return  this.httpClient.post(`${this.API_URL}`,ngo,httpOptions);
}


}
