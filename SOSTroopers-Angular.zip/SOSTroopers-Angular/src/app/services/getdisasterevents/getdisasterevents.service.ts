import { Injectable } from '@angular/core';
import { HttpClient,HttpErrorResponse} from  '@angular/common/http';

import { HttpHeaders } from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json'
  })
};

@Injectable({
  providedIn: 'root'
})
export class GetDisasterEventsService {
  API_URL:string;
 constructor(private  httpClient:  HttpClient) {}
 GetDisasterEvents(){
    this.API_URL  = "https://service.us.apiconnect.ibmcloud.com/gws/apigateway/api/d72617952b6f833daed5f62c7bc04a4d0355d4ee01a6f56fa4196b262b66b87a/bcdc27ad-04d6-4abe-a453-ab05db8d2da3/getAllEvents"
    return  this.httpClient.get(`${this.API_URL}`,httpOptions);
}
getShelterByDisasterAndNGO(disasterName,NGOName){
 this.API_URL  = "https://disaster-business-network-blockchain-dda8f00fb8745b9c1e48.mybluemix.net/api/queries/select_shelter_by_NGO_Disasterevent?event="+disasterName+"&NGOName="+NGOName;
 //"https://service.us.apiconnect.ibmcloud.com/gws/apigateway/api/d72617952b6f833daed5f62c7bc04a4d0355d4ee01a6f56fa4196b262b66b87a/771d0251-635f-45d0-af7d-192487576aab/selectShelterByNGODisasterEvent?NGOName="+NGOName+"&event="+disasterName;
return  this.httpClient.get(`${this.API_URL}`,httpOptions);
}

getDisasterByStatus(status){
 this.API_URL  = "https://disaster-business-network-blockchain-dda8f00fb8745b9c1e48.mybluemix.net/api/queries/selectActiveDisaster?status="+status
 //"https://service.us.apiconnect.ibmcloud.com/gws/apigateway/api/d72617952b6f833daed5f62c7bc04a4d0355d4ee01a6f56fa4196b262b66b87a/27a06e56-1d8d-491d-be67-92693d29f878/selectActiveDisasters?status="+status;
return  this.httpClient.get(`${this.API_URL}`,httpOptions);
}

getDisasterById(id){
 this.API_URL  = "https://disaster-business-network-blockchain-dda8f00fb8745b9c1e48.mybluemix.net/api/Disaster_Event/"+id;
return  this.httpClient.get(`${this.API_URL}`,httpOptions);
}


}
