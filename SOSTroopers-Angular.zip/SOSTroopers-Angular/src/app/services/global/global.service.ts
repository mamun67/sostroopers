import { Injectable } from '@angular/core';

@Injectable()
export class GlobalService {

    private disasterId:any=0;
    private disaster:any;
    private user:any;
    constructor() { }
    setDisasterId(val) {
        this.disasterId = val;
    }
    getDisasterId() {
        return this.disasterId;
    }

    setDisaster(val) {
        this.disaster = val;
    }
    getDisaster() {
        return this.disaster;
    }

    setUser(val) {
        this.user = val;
    }
     getUser() {
        return this.user;
    }




    getId() {
        var date = new Date();
        var timestamp =date.getTime();
        var rand=Math.round(Math.random() * (99999 - 10000)) + 10000;
        return rand+""+timestamp
    }

}
