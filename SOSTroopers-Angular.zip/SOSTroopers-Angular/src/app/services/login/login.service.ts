import { Injectable } from '@angular/core';
import { HttpClient,HttpErrorResponse} from  '@angular/common/http';

import { HttpHeaders } from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json'
  })
};

@Injectable({
  providedIn: 'root'
})
export class LoginService {

    API_URL  =  "";
 constructor(private  httpClient:  HttpClient) {}
 login(user){
    this.API_URL  =  "https://service.us.apiconnect.ibmcloud.com/gws/apigateway/api/d72617952b6f833daed5f62c7bc04a4d0355d4ee01a6f56fa4196b262b66b87a/d0c55732-c52a-48b8-b6ee-8d7c663836d9/login";
    return  this.httpClient.post(`${this.API_URL}`,user,httpOptions);
}

updatePwd(url,user){
    this.API_URL  =url;
    return  this.httpClient.put(`${this.API_URL}`,user,httpOptions);
}
}
