import { Injectable } from '@angular/core';
import { HttpClient,HttpErrorResponse} from  '@angular/common/http';

import { HttpHeaders } from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json'
  })
};

@Injectable({
  providedIn: 'root'
})
export class NGORegisterService {
 API_URL  =  "";//http://ec2-18-216-142-134.us-east-2.compute.amazonaws.com:3000/api/NGO";
 constructor(private  httpClient:  HttpClient) {}
 NGORegister(ngo){
   this.API_URL  =  "https://disaster-business-network-blockchain-dda8f00fb8745b9c1e48.mybluemix.net/api/NGO"
    return  this.httpClient.post(`${this.API_URL}`,ngo,httpOptions);
}

 updateNGO(ngo){
   this.API_URL  =  "https://disaster-business-network-blockchain-dda8f00fb8745b9c1e48.mybluemix.net/api/NGO/"+ngo.NGO_Email;
    return  this.httpClient.put(`${this.API_URL}`,ngo,httpOptions);
}

 
}
