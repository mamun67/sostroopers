import { Injectable } from '@angular/core';
import { HttpClient,HttpErrorResponse} from  '@angular/common/http';

import { HttpHeaders } from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json'
  })
};


@Injectable({
  providedIn: 'root'
})
export class RequestsService {

   API_URL  =  "";
 constructor(private  httpClient:  HttpClient) {}
 raiseRequest(request){
   this.API_URL="https://disaster-business-network-blockchain-dda8f00fb8745b9c1e48.mybluemix.net/api/RaiseRequest";
    return  this.httpClient.post(`${this.API_URL}`,request,httpOptions);
}

 getAllRequests(){
   this.API_URL="https://disaster-business-network-blockchain-dda8f00fb8745b9c1e48.mybluemix.net/api/RaiseRequest";
    return  this.httpClient.get(`${this.API_URL}`,httpOptions);
}

updateRequests(request){
   this.API_URL="https://disaster-business-network-blockchain-dda8f00fb8745b9c1e48.mybluemix.net/api/RaiseRequest/"+request.request_Id;
    return  this.httpClient.put(`${this.API_URL}`,request,httpOptions);
}

getAllNGORequests(ngo){
   this.API_URL="https://disaster-business-network-blockchain-dda8f00fb8745b9c1e48.mybluemix.net/api/queries/select_RaiseRequest_by_NGO?NGO="+ngo;
    return  this.httpClient.get(`${this.API_URL}`,httpOptions);
}

}
