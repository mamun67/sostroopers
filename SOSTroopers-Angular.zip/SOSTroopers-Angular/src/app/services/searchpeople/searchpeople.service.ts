import { Injectable } from '@angular/core';
import { HttpClient,HttpErrorResponse} from  '@angular/common/http';

import { HttpHeaders } from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json'
  })
};

@Injectable({
  providedIn: 'root'
})
export class SearchpeopleService {
  API_URL:string;
 constructor(private  httpClient:  HttpClient) {}
 searchPeople(user){
   if(user.fname=="" || user.fname==undefined){
     this.API_URL  ="https://disaster-business-network-blockchain-dda8f00fb8745b9c1e48.mybluemix.net/api/queries/selectResidentByLastName?Lastname="+user.lname;
   }
   else if(user.lname=="" || user.lname==undefined){
     this.API_URL  ="https://disaster-business-network-blockchain-dda8f00fb8745b9c1e48.mybluemix.net/api/queries/selectResidentByFirstName?Firstname="+user.fname;
   }else{
     this.API_URL  ="https://disaster-business-network-blockchain-dda8f00fb8745b9c1e48.mybluemix.net/api/queries/selectResidentByFullName?Firstname="+user.fname+"&Lastname="+user.lname;
   }
   
    return  this.httpClient.get(`${this.API_URL}`,httpOptions);
  
}

 searchPeopleByBiometric(biometric){

    this.API_URL  = "https://disaster-business-network-blockchain-dda8f00fb8745b9c1e48.mybluemix.net/api/queries/selectResidentByBiometric?biometric="+biometric;
    return  this.httpClient.get(`${this.API_URL}`,httpOptions);
}

searchPeopleByEmail(email){
  
    this.API_URL  = "https://disaster-business-network-blockchain-dda8f00fb8745b9c1e48.mybluemix.net/api/Resident/"+email
    return  this.httpClient.get(`${this.API_URL}`,httpOptions);
}

}
