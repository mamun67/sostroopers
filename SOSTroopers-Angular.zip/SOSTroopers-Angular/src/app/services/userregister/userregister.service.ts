import { Injectable } from '@angular/core';
import { HttpClient,HttpErrorResponse} from  '@angular/common/http';

import { HttpHeaders } from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json'
  })
};

@Injectable({
  providedIn: 'root'
})
export class UserRegisterService {
 API_URL  =  ""//http://ec2-18-216-142-134.us-east-2.compute.amazonaws.com:3000/api/Resident";
 constructor(private  httpClient:  HttpClient) {}
 UserRegister(user){
   this.API_URL="https://disaster-business-network-blockchain-dda8f00fb8745b9c1e48.mybluemix.net/api/Resident";
    return  this.httpClient.post(`${this.API_URL}`,user,httpOptions);
}

 updateResident(user){
   this.API_URL="https://disaster-business-network-blockchain-dda8f00fb8745b9c1e48.mybluemix.net/api/Resident/"+user.Resident_Email;
    return  this.httpClient.put(`${this.API_URL}`,user,httpOptions);
}
 
}
