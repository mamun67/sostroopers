import { Injectable } from '@angular/core';
import { HttpClient,HttpErrorResponse} from  '@angular/common/http';


import { HttpHeaders } from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json'
  })
};


@Injectable({
  providedIn: 'root'
})
export class WeatherapiService {
 API_URL:string  =  "";
 constructor(private  httpClient:  HttpClient) {}
 getWeatherDetails(body){
   this.API_URL="https://service.us.apiconnect.ibmcloud.com/gws/apigateway/api/d72617952b6f833daed5f62c7bc04a4d0355d4ee01a6f56fa4196b262b66b87a/36fac5c2-75f7-42d3-bd82-f29f7c276e2d/getWeatherCompanyData";
   //"https://31473b69-206a-4ce8-b2dd-fbf0990860fb:OtZyn4HxXR@twcservice.mybluemix.net:443/api/weather/v1/geocode/"+lat+"/"+longi+"/forecast/daily/3day.json"
    return  this.httpClient.post(`${this.API_URL}`,body,httpOptions);
}
 
}
