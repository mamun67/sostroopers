import { Component, OnInit, Inject } from '@angular/core';
import { GlobalService } from '../services/global/global.service';
import { ActivatedRoute, Router} from '@angular/router';
import {LOCAL_STORAGE, WebStorageService} from 'angular-webstorage-service';
import { CreateShelterService } from '../services/createshelter/createshelter.service';
declare var jquery: any;
declare var $: any; 

@Component({
  selector: 'app-showShelter',
  templateUrl: './showShelter.component.html',
  styleUrls: ['./showShelter.component.css']
})
export class ShowShelterComponent implements OnInit {
   user:any={};
  
   showbranches:boolean=false;
   servicesProvide:string="";
   userf:any={};
   errorpng:boolean=false;
   shelterName:string="";
   shelter:any={};
  constructor(private activatedRoute: ActivatedRoute,private router:Router,private createShelterService:CreateShelterService,@Inject(LOCAL_STORAGE) private storage: WebStorageService,private globalService:GlobalService) {
      this.user=this.storage.get("user");
        if($.isEmptyObject(this.user)){
          this.user={
            "Role":""
          }
        }
  
    

   }
sub;
message:string="";
  ngOnInit() {
     this.sub = this.activatedRoute.queryParams
                    .subscribe(params => { 
                     this.shelterName = params['shelterName'] ||"";
                     
                     console.log('Query params ',this.shelter) });

                     if(this.shelterName!=""){
                       
                        this.getShelter();
                     }
                     else {
                       this.errorpng=true;
                       this.message="Shelter not found..!!"
      
                     }
}


   
   getShelter(){
     $(".overlay").show();
     this.createShelterService.getShelter(this.shelterName).subscribe((data: any) => {
      $(".overlay").hide();
      // this.allDisasters=data
        this.shelter=data;
        this.errorpng=false;
         setTimeout(() => {
      // this.showloader = false;
         $("#defaultOpen2").click();
       // document.getElementById("defaultOpen").click();
    }, 3);
        
      console.log(data);
    }, error => {
      $(".overlay").hide();
      this.errorpng=true;
      this.message="Something went wrong.."
      $("#showMessage").modal();
      console.log(error);
    }
    );

   }

}
