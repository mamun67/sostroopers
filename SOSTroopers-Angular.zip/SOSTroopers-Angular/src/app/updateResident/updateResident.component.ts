import { Component, OnInit, Inject } from '@angular/core';
import { UserRegisterService } from '../services/userregister/userregister.service';
import { NGORegisterService } from '../services/ngoregister/ngoregister.service';
import { GlobalService } from '../services/global/global.service';
import { FormGroup, Validators, FormControl, FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router} from '@angular/router';
import {LOCAL_STORAGE, WebStorageService} from 'angular-webstorage-service';
// import { pwdMatcher } from '../matchPwd/matchPwd.component';

declare var jquery: any;
declare var $: any;
declare function myMethod():any;
 
@Component({
  selector: 'app-update-resident',
  templateUrl: './updateResident.component.html',
  styleUrls: ['./updateResident.component.css']
})
export class UpdateResidentComponent implements OnInit {
  user: any;
  response: any;
  error: any;
  angForm1: FormGroup;
  angForm: FormGroup;
  resourcesForm:FormGroup;
  userf:any={};
  minDate:string="";
  maxDate:string="";
  dd:any;
  mm:any;
  country:string;
  state:string;
  district:string;
  zipcode:string;
  other:string;
  AreaName:string;
  loader:boolean=false;
   message:string="";
  errorpng:boolean=false;
  constructor(@Inject(LOCAL_STORAGE) private storage: WebStorageService,private ngoRegisterService: NGORegisterService,private globalService: GlobalService,private activatedRoute: ActivatedRoute,private router:Router, @Inject(UserRegisterService) private userRegisterService: UserRegisterService, private fb: FormBuilder) {
     this.user=this.storage.get("user");
        if($.isEmptyObject(this.user)){
          this.user={
            "Role":""
          }
        }
    var date=new Date();

    this.dd = date.getDate();
    this.mm = date.getMonth()+1; //January is 0!
    var yyyy = date.getFullYear();
    if(this.dd<10){
        this.dd='0'+this.dd;
    } 
    if(this.mm<10){
        this.mm='0'+this.mm;
    } 
    this.maxDate=yyyy+'-'+this.mm+'-'+this.dd;
    date.setFullYear(new Date().getFullYear()-120)
    this.minDate=date.getFullYear()+'-'+this.mm+'-'+this.dd;
  //   this.userf={
  //   "$class": "org.disaster.model.Resident",
  //   "FirstName": "Swati",
  //   "LastName": "Swati",
  //   "Father_Name": "Harendra",
  //   "DOB": "01 Nov 1993",
  //   "Addr": {
  //     "$class": "org.disaster.model.Address",
  //     "Country": "string",
  //     "State": "string",
  //     "District": "string",
  //     "Zip_Code": "string",
  //     "Area": "string",
  //     "Other": "string",
  //     "id": "string"
  //   },
  //   "Role":"resident",
  //   "Resident_Email": "des@gmail.com",
  //   "Contact": "746874612",
  //   "Biometric": "vBIyPO=",
  //   "BloodGroup": "O+",
  //   "shelter": []
  // }

  // this.user= {
  //   "$class": "org.disaster.model.NGO",
  //   "GlobalId": "string",
  //   "Name": "string",
  //   "Admin": "string",
  //   "Role":"ngo",
  //   "Addr": {
  //     "$class": "org.disaster.model.Address",
  //     "Country": "string",
  //     "State": "string",
  //     "District": "string",
  //     "Zip_Code": "string",
  //     "Area": "string",
  //     "Other": "string",
  //     "id": "string"
  //   },
  //   "NGO_Email": "string",
  //   "Contact": "string",
  //   "Branches": [],
  //   "Status": true,
  //   "Blacklist": true,
  //   "ServicesProvide": [],
  //   "Active_event": [],
  //   "Past_Disaster": {
  //     "$class": "org.disaster.model.Disaster_Event",
  //     "Event_Id": "string",
  //     "EventName": "string",
  //     "Created_Date": "2018-09-15T17:08:56.974Z",
  //     "End_Date": "2018-09-15T17:08:56.974Z",
  //     "loc": {
  //       "$class": "org.disaster.model.DisLocation",
  //       "State": "string",
  //       "Country": "string",
  //       "id": "string"
  //     },
  //     "Type_Of_Disaster": "string",
  //     "AreaAffected": [],
  //     "Types_Of_Help_Needed": [],
  //     "status": true,
  //     "CreatedBy": {},
  //     "ngos": [
  //       {}
  //     ]
  //   }
  // }
  
    if(this.user.Role=='ngo'){
      this.showModal();
    }

    else if(this.user.Role=='resident'){
      this.showResident();
    }
    else{
      this.errorpng=true;
      this.message="Not Logged In "
      $('#messageModal').modal();
    }
  
  
  }

  


branches:string="";
dob:string="";
showResident(){
  this.country=this.user.Addr.Country;
  this.state=this.user.Addr.State;
  this.district=this.user.Addr.District;
  this.AreaName=this.user.Addr.Area;
  this.other=this.user.Addr.Other;
  this.zipcode=this.user.Addr.Zip_Code;
  this.user.DOB=this.user.DOB.slice(0,10);
}

updateResident() {
    

    this.user["Addr"]={
      "$class": "org.disaster.model.Address",
    "Country": this.country,
    "State": this.state,
    "District": this.district,
    "Zip_Code": this.zipcode,
    "Area": this.AreaName,
    "Other": this.other
    }
    console.log("here calling servie.......")
     $(".overlay").show();
    this.userRegisterService.updateResident(this.user).subscribe((data: any) => {

      this.response = data;
       this.message="Updated Successfully..!";
        $(".overlay").hide();
      this.errorpng=false;
      $('#messageModal').modal();
      console.log(data);
    }, error => {
      this.error = error // error path);
       this.message="Something went wrong..!!";
      this.errorpng=true;
        $(".overlay").hide();
       $('#messageModal').modal();
      console.log(this.error);
    }
    );
  }

shelter:string="";
medical:string="";
status:string="";
showModal(){
        
     this.country=this.user.Addr.Country;
  this.state=this.user.Addr.State;
  this.district=this.user.Addr.District;
  this.AreaName=this.user.Addr.Area;
  this.other=this.user.Addr.Other;
  this.zipcode=this.user.Addr.Zip_Code;
    
        
     if(this.user.Status==true){
       this.status='active';
     }else{
       this.status='inactive';
     }

     this.tempResourcesRequest=[];
     this.tempResourcesRequest=this.user.Branches;
     
     for(let index=0; index<this.user.ServicesProvide.length; index++){
       if(this.user.ServicesProvide[index]=='Shelter'){
         this.shelter="shelter";
       }
       else if(this.user.ServicesProvide[index]=='Medical'){
         this.medical="medical";
       }
     }

     for(let index=0; index<this.tempResourcesRequest.length; index++){
       this.tempResourcesRequest[index]["isEdit"]=false;
     }
     this.isEdit=this.tempResourcesRequest.length;
    
   }


  redirect(){
    this.router.navigate(['./home']);
  }
  ngOnInit() {
    setTimeout(()=>{
      myMethod();
    },3)
    

    this.angForm1 = new FormGroup({
      fname: new FormControl('', Validators.compose([
        Validators.required,
        Validators.maxLength(25),
        Validators.pattern('^[A-Za-z ]+$')
      ])),

      lname: new FormControl('', Validators.compose([
        Validators.required,
        Validators.maxLength(25),
        Validators.pattern('^[A-Za-z ]+$')
      ])),

      fathername: new FormControl('', Validators.compose([
        Validators.required,
        Validators.maxLength(25),
        Validators.pattern('^[A-Za-z ]+$')
      ])),

     
       country: new FormControl('',Validators.compose([
        Validators.required,
        
      ])),
       state: new FormControl('',Validators.compose([
        Validators.required,
        
      ])),

 

       district: new FormControl('',Validators.compose([
        Validators.required,
        Validators.minLength(3),
        Validators.maxLength(25),
        Validators.pattern('^[a-zA-Z ]+$')
      ])),
       AreaName: new FormControl('',Validators.compose([
        Validators.required,
        Validators.minLength(3),
        Validators.maxLength(25),
        Validators.pattern('^[a-zA-Z0-9-/ ]+$')
      ])),
       other: new FormControl(''),
       zipcode:new FormControl('',Validators.compose([
        Validators.required,
        Validators.pattern('^[0-9]{6}$')
      ])),

      gender: new FormControl('', Validators.compose([
        Validators.required
      ])),

      bday: new FormControl('', Validators.compose([
        Validators.required
      ])),

      blood: new FormControl(''),

      phone: new FormControl('', Validators.compose([
        Validators.required,
        Validators.minLength(10),
        Validators.maxLength(10),
        Validators.pattern('^[0-9]+$')
      ]))

    })


    this.angForm = new FormGroup({
      name: new FormControl('', Validators.compose([
        Validators.required,
        Validators.maxLength(25),
        Validators.minLength(5),
        Validators.pattern('^[A-Za-z ]+$')
      ])),

      global: new FormControl('', Validators.compose([
        Validators.required,
        Validators.maxLength(10),
        Validators.minLength(4),
        Validators.pattern('^[0-9]+$')
      ])),

      admin: new FormControl('', Validators.compose([
        Validators.required,
        Validators.maxLength(25),
        Validators.minLength(5),
        Validators.pattern('^[A-Za-z ]+$')
      ])),

      // email: new FormControl('', Validators.compose([
      //   Validators.required,
      //   Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
      // ])),
          country: new FormControl('',Validators.compose([
        Validators.required,
        
      ])),
       state: new FormControl('',Validators.compose([
        Validators.required,
        
      ])),
       district: new FormControl('',Validators.compose([
        Validators.required,
        Validators.minLength(3),
        Validators.maxLength(25),
        Validators.pattern('^[a-zA-Z ]+$')
      ])),
       AreaName: new FormControl('',Validators.compose([
        Validators.required,
        Validators.minLength(3),
        Validators.maxLength(25),
        Validators.pattern('^[a-zA-Z0-9-/ ]+$')
      ])),
       other: new FormControl(''),
       zipcode:new FormControl('',Validators.compose([
        Validators.required,
        Validators.pattern('^[0-9]{6}$')
      ])),
    

      phone: new FormControl('', Validators.compose([
        Validators.required,
        Validators.minLength(10),
        Validators.maxLength(10),
        Validators.pattern('^[0-9]+$')
        // Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
      ])),

          status: new FormControl(''),
      shelter: new FormControl(''),
      medical: new FormControl(''),
    


    })

     this.resourcesForm = new FormGroup({
      branchname: new FormControl('', Validators.compose([
        Validators.required,  
        Validators.pattern('^[A-Za-z ]+$')
      ])),

      //  resourceCount: new FormControl('', Validators.compose([
      //   Validators.required,  
      //   Validators.pattern('^[0-9]+$')
      // ])),
      

      state: new FormControl('', Validators.compose([
        Validators.required,  
         Validators.pattern('^[A-Za-z ]+$')
      ])),


      country: new FormControl('', Validators.compose([
        Validators.required,  
         Validators.pattern('^[A-Za-z ]+$')
      ])),

        
       district: new FormControl('',Validators.compose([
        Validators.required,
        Validators.minLength(3),
        Validators.maxLength(25),
        Validators.pattern('^[a-zA-Z ]+$')
      ])),
       area: new FormControl('',Validators.compose([
        Validators.required,
        Validators.minLength(3),
        Validators.maxLength(25),
        Validators.pattern('^[a-zA-Z0-9-/ ]+$')
      ])),
       other: new FormControl(''),
       zipcode:new FormControl('',Validators.compose([
        Validators.required,
        Validators.pattern('^[0-9]{6}$')
      ])),
      
    })
  }

  serviceProvide:any=[];
  updateNGO() {
    this.serviceProvide=[];
        this.user["Addr"]={
      "$class": "org.disaster.model.Address",
    "Country": this.country,
    "State": this.state,
    "District": this.district,
    "Zip_Code": this.zipcode,
    "Area": this.AreaName,
    "Other": this.other
  }
  
    if (this.shelter) {
      this.serviceProvide.push('shelter');
    }
    if (this.medical) {
      this.serviceProvide.push('medical');
    }
    this.user.ServicesProvide = this.serviceProvide;
  
    if(this.status=='active'){
       this.user.Status=true;
     }else{
       this.user.Status=false;
     }
   
   for(var i=0; i<this.tempResourcesRequest.length;i++){
       delete this.tempResourcesRequest[i]["isEdit"];
     }

      this.user["Branches"] = this.tempResourcesRequest; 
    console.log("here calling servie.......")
     $(".overlay").show();
    this.ngoRegisterService.updateNGO(this.user).subscribe((data: any) => {
       $(".overlay").hide();
      this.response = data;
      this.storage.set("user",this.user);
      this.message="Updated Successfully..!!";
      this.errorpng=false;
       $("#messageModal").modal();
      
      //this.router.navigate(['./home']);
      console.log(data);
    }, error => {
       $(".overlay").hide();
      this.error = error // error path);
      this.message="Something went wrong..!!";
      this.errorpng=true;
       $("#messageModal").modal();
      // $("#messageModal").modal();
      console.log(this.error);
    }
    );
  }

  tempResourcesRequest=[];
  addRow(){
     
     this.tempResourcesRequest.push({
        "$class": "org.disaster.model.Branches",
        "AreaName": "",
        "add":{
            "Country": "",
            "State": "",
            "District": "",
            "Area": "",
            "Other": "",
            "Zip_Code": ""
        },
        
        "isEdit":true
      })
  }

  isEdit:number=0;
 findCount(index){
   this.tempResourcesRequest[index].isEdit=false;
   this.isEdit=0;
   for(var i=0; i<this.tempResourcesRequest.length;i++){
     if(this.tempResourcesRequest[i].isEdit==false){
       this.isEdit=this.isEdit+1;
     }
    
   }
 }

 deleteResource(index){
   this.tempResourcesRequest.splice(index,1);
 }

 

  account_validation_messages1 = {
    'fname': [
      { type: 'required', message: 'First Name is required' },
      { type: 'maxlength', message: 'First Name cannot be more than 25 characters long' },
      { type: 'pattern', message: 'First Name must contain only letters' }
    ],

    'lname': [
      { type: 'required', message: 'Last Name is required' },
      { type: 'maxlength', message: 'Last Name cannot be more than 25 characters long' },
      { type: 'pattern', message: 'Last Name must contain only letters' }
    ],

    'fathername': [
      { type: 'required', message: 'Name is required' },
      { type: 'maxlength', message: 'Name cannot be more than 25 characters long' },
      { type: 'pattern', message: 'Name must contain only letters' }
    ],


     'country': [
      { type: 'required', message: 'Country is required' },
    
    ],

      'state': [
      { type: 'required', message: 'State is required' },
    
    ],
      'district': [
      { type: 'required', message: 'District is required' },
      { type: 'minlength', message: 'District must be at least 3 characters long' },
       { type: 'maxlength', message: 'District cannot be more than 25 characters long' },
      { type: 'pattern', message: 'Please enter alphabets only' }
    ],
      'AreaName': [
      { type: 'required', message: 'Area Name is required' },
      { type: 'minlength', message: 'Area Name must be at least 3 characters long' },
       { type: 'maxlength', message: 'Area Name cannot be more than 25 characters long' },
      { type: 'pattern', message: 'Please enter this a-zA-Z0-9-/ characters only' }
    ],
    'zipcode': [
      { type: 'required', message: 'ZipCode is required' },
 
      { type: 'pattern', message: 'Please enter 6 numbers only' }
    ],

    'gender': [
      { type: 'required', message: 'Gender is required' }
    ],

    'bday': [
      { type: 'required', message: 'Birthday is required' }
    ],

    'phone': [
      { type: 'required', message: 'Mobile number is required' },
      { type: 'minlength', message: 'Mobile number must be at contain 10 characters long' },
      { type: 'maxlength', message: 'Mobile number must be at contain 10 characters long' },
      { type: 'pattern', message: 'Mobile number must contain only numbers' }
    ]

  }


  account_validation_messages = {
    'name': [
      { type: 'required', message: 'Name is required' },
      { type: 'minlength', message: 'Name must be at least 5 characters long' },
      { type: 'maxlength', message: 'Name cannot be more than 25 characters long' },
      { type: 'pattern', message: 'Name must contain only letters' }
    ],

    'global': [
      { type: 'required', message: 'Global Id is required' },
      { type: 'minlength', message: 'Global Id must be at least 4 characters long' },
      { type: 'maxlength', message: 'Global Id cannot be more than 10 characters long' },
      { type: 'pattern', message: 'Global Id must contain only numbers' }
    ],

    'admin': [
      { type: 'required', message: 'Admin is required' },
      { type: 'minlength', message: 'Admin must be at least 4 characters long' },
      { type: 'maxlength', message: 'Admin cannot be more than 25 characters long' },
      { type: 'pattern', message: 'Admin must contain only letters' }
    ],

    'email': [
      { type: 'required', message: 'Email is required' },
      // { type: 'minlength', message: 'Email must be at least 4 characters long' },
      // { type: 'maxlength', message: 'Email cannot be more than 10 characters long' },
      { type: 'pattern', message: 'Please enter a valid email' }
    ],

      'country': [
      { type: 'required', message: 'Country is required' },
    
    ],

      'state': [
      { type: 'required', message: 'State is required' },
    
    ],
      'district': [
      { type: 'required', message: 'District is required' },
      { type: 'minlength', message: 'District must be at least 3 characters long' },
       { type: 'maxlength', message: 'District cannot be more than 25 characters long' },
      { type: 'pattern', message: 'Please enter alphabets only' }
    ],
      'AreaName': [
      { type: 'required', message: 'Area Name is required' },
      { type: 'minlength', message: 'Area Name must be at least 3 characters long' },
       { type: 'maxlength', message: 'Area Name cannot be more than 25 characters long' },
      { type: 'pattern', message: 'Please enter this a-zA-Z0-9-/ characters only' }
    ],
    'zipcode': [
      { type: 'required', message: 'ZipCode is required' },
 
      { type: 'pattern', message: 'Please enter 6 numbers only' }
    ],

     'branchname': [
      { type: 'required', message: 'Branch name is required' },
      
      { type: 'pattern', message: 'Branch name must contain only letters' }
    ],

      'pwd': [
      { type: 'required', message: 'Password is required' }
    ],
    'repwd': [
      { type: 'isError', message: 'Password & Confirm Password should match' }
    ],

    'phone': [
      { type: 'required', message: 'Mobile number is required' },
      { type: 'minlength', message: 'Mobile number must be at contain 10 characters long' },
      { type: 'maxlength', message: 'Mobile number must be at contain 10 characters long' },
      { type: 'pattern', message: 'Mobile number must contain only numbers' }
    ]

  }



}
