import { Component, OnInit, Inject } from '@angular/core';
import { UserRegisterService } from '../services/userregister/userregister.service';
import { FormGroup, Validators, FormControl, FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router} from '@angular/router';
import { PasswordValidation } from '../matchPwd/matchPwd.component';

declare var jquery: any;
declare var $: any;
declare function myMethod():any;

@Component({
  selector: 'app-maps',
  templateUrl: './userreg.component.html',
  styleUrls: ['./userreg.component.css']
})
export class UserRegComponent implements OnInit {
  user: any;
  response: any;
  error: any;
  angForm: FormGroup;
  hashValue: string;
  fingerprintShow: boolean;

  minDate:string="";
  maxDate:string="";
  dd:any;
  mm:any;
  country:string;
  state:string;
  district:string;
  zipcode:string;
  other:string;
  AreaName:string;
  loader:boolean=false;

  constructor(private activatedRoute: ActivatedRoute,private router:Router, @Inject(UserRegisterService) private userRegisterService: UserRegisterService, private fb: FormBuilder) {
    this.user = {};
    this.country="-1";
    this.other="";
    this.user.Gender="";
    this.user.BloodGroup="";

    var date=new Date();

    this.dd = date.getDate();
    this.mm = date.getMonth()+1; //January is 0!
    var yyyy = date.getFullYear();
    if(this.dd<10){
        this.dd='0'+this.dd;
    } 
    if(this.mm<10){
        this.mm='0'+this.mm;
    } 
    this.maxDate=yyyy+'-'+this.mm+'-'+this.dd;
    date.setFullYear(new Date().getFullYear()-120)
    this.minDate=date.getFullYear()+'-'+this.mm+'-'+this.dd;// date.toLocaleDateString();
    
    console.log("maxDate:"+this.maxDate);
    console.log("minDate:"+this.minDate);
  }

   message:string="";
  errorpng:boolean=false;

  userRegister() {
    this.fingerprintShow = true;
    setTimeout(() => {
      this.fingerprintShow = false
    }, 3000)
    this.user["$class"] = "org.disaster.model.Resident";
    this.user["shelter"] = [];
    this.user["Biometric"] = this.hashValue;
    this.user["Addr"]={
      "$class": "org.disaster.model.Address",
    "Country": this.country,
    "State": this.state,
    "District": this.district,
    "Zip_Code": this.zipcode,
    "Area": this.AreaName,
    "Other": this.other
    }
    console.log("here calling servie.......")
    this.loader=true;
    this.userRegisterService.UserRegister(this.user).subscribe((data: any) => {

      this.response = data;
       this.message="Registered Successfully..! You may login now";
       this.loader=false;
      this.errorpng=false;
      console.log(data);
    }, error => {
      this.error = error // error path);
       this.message="Something went wrong..!!";
      this.errorpng=true;
       this.loader=false;
      console.log(this.error);
    }
    );
  }

  dec2hex(dec) { return ('0' + dec.toString(16)).substr(-2) }
  getHash() {
    let valueRandom = "Value Changed"
    let arr = new Uint8Array(40 / 2)
    window.crypto.getRandomValues(arr)
    this.hashValue = Array.from(arr, this.dec2hex).join('').toUpperCase()
  }

  redirect(){
    this.router.navigate(['./home']);
  }
  ngOnInit() {
    myMethod();
    //For Hash Thing
    function dec2hex(dec) { return ('0' + dec.toString(16)).substr(-2) }

    let valueRandom = "Value Changed"
    let arr = new Uint8Array(40 / 2)
    window.crypto.getRandomValues(arr)
    this.hashValue = Array.from(arr, this.dec2hex).join('').toUpperCase()
    console.log('Hash value in getHash Function, ', this.hashValue)

    // End of hash function

    this.angForm = new FormGroup({
      fname: new FormControl('', Validators.compose([
        Validators.required,
        Validators.maxLength(25),
        Validators.pattern('^[A-Za-z ]+$')
      ])),

      lname: new FormControl('', Validators.compose([
        Validators.required,
        Validators.maxLength(25),
        Validators.pattern('^[A-Za-z ]+$')
      ])),

      fathername: new FormControl('', Validators.compose([
        Validators.required,
        Validators.maxLength(25),
        Validators.pattern('^[A-Za-z ]+$')
      ])),

      email: new FormControl('', Validators.compose([
        Validators.required,
        Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
      ])),

      pwd: new FormControl('',Validators.compose([
        Validators.required
      ])),
      repwd: new FormControl('',Validators.compose([
        PasswordValidation
        
      ])),
       country: new FormControl('',Validators.compose([
        Validators.required,
        
      ])),
       state: new FormControl('',Validators.compose([
        Validators.required,
        
      ])),
       district: new FormControl('',Validators.compose([
        Validators.required,
        Validators.minLength(3),
        Validators.maxLength(25),
        Validators.pattern('^[a-zA-Z ]+$')
      ])),
       AreaName: new FormControl('',Validators.compose([
        Validators.required,
        Validators.minLength(3),
        Validators.maxLength(25),
        Validators.pattern('^[a-zA-Z0-9-/ ]+$')
      ])),
       other: new FormControl(''),
       zipcode:new FormControl('',Validators.compose([
        Validators.required,
        Validators.pattern('^[0-9]{6}$')
      ])),

      gender: new FormControl('', Validators.compose([
        Validators.required
      ])),

      bday: new FormControl('', Validators.compose([
        Validators.required
      ])),

      blood: new FormControl(''),

      phone: new FormControl('', Validators.compose([
        Validators.required,
        Validators.minLength(10),
        Validators.maxLength(10),
        Validators.pattern('^[0-9]+$')
      ]))

    })
  }

  account_validation_messages = {
    'fname': [
      { type: 'required', message: 'First Name is required' },
      { type: 'maxlength', message: 'First Name cannot be more than 25 characters long' },
      { type: 'pattern', message: 'First Name must contain only letters' }
    ],

    'lname': [
      { type: 'required', message: 'Last Name is required' },
      { type: 'maxlength', message: 'Last Name cannot be more than 25 characters long' },
      { type: 'pattern', message: 'Last Name must contain only letters' }
    ],

    'fathername': [
      { type: 'required', message: 'Name is required' },
      { type: 'maxlength', message: 'Name cannot be more than 25 characters long' },
      { type: 'pattern', message: 'Name must contain only letters' }
    ],

    'email': [
      { type: 'required', message: 'Email is required' },
      { type: 'pattern', message: 'Please enter valid email' }
    ],

   
    'pwd': [
      { type: 'required', message: 'Password is required' }
    ],
    'repwd': [
      { type: 'isError', message: 'Password & Confirm Password should match' }
    ],

     'country': [
      { type: 'required', message: 'Country is required' },
    
    ],

      'state': [
      { type: 'required', message: 'State is required' },
    
    ],
      'district': [
      { type: 'required', message: 'District is required' },
      { type: 'minlength', message: 'District must be at least 3 characters long' },
       { type: 'maxlength', message: 'District cannot be more than 25 characters long' },
      { type: 'pattern', message: 'Please enter alphabets only' }
    ],
      'AreaName': [
      { type: 'required', message: 'Area Name is required' },
      { type: 'minlength', message: 'Area Name must be at least 3 characters long' },
       { type: 'maxlength', message: 'Area Name cannot be more than 25 characters long' },
      { type: 'pattern', message: 'Please enter this a-zA-Z0-9-/ characters only' }
    ],
    'zipcode': [
      { type: 'required', message: 'ZipCode is required' },
 
      { type: 'pattern', message: 'Please enter 6 numbers only' }
    ],

    'gender': [
      { type: 'required', message: 'Gender is required' }
    ],

    'bday': [
      { type: 'required', message: 'Birthday is required' }
    ],

    'phone': [
      { type: 'required', message: 'Mobile number is required' },
      { type: 'minlength', message: 'Mobile number must be at contain 10 characters long' },
      { type: 'maxlength', message: 'Mobile number must be at contain 10 characters long' },
      { type: 'pattern', message: 'Mobile number must contain only numbers' }
    ]

  }

}
