import { Component, OnInit, Inject } from '@angular/core';
import { GlobalService } from '../services/global/global.service';
import {LOCAL_STORAGE, WebStorageService} from 'angular-webstorage-service';
declare var jquery: any;
declare var $: any; 

@Component({
  selector: 'app-viewprofile',
  templateUrl: './viewprofile.component.html',
  styleUrls: ['./viewprofile.component.css']
})
export class ViewprofileComponent implements OnInit {
   user:any={};
  
   showbranches:boolean=false;
   servicesProvide:string="";
   userf:any={};
  constructor(@Inject(LOCAL_STORAGE) private storage: WebStorageService,private globalService:GlobalService) {
      this.user=this.storage.get("user");
        if($.isEmptyObject(this.user)){
          this.user={
            "Role":""
          }
        }
  //   this.user={
  //   "$class": "org.disaster.model.Resident",
  //   "FirstName": "Swati",
  //   "LastName": "Swati",
  //   "Father_Name": "Harendra",
  //   "DOB": "01 Nov 1993",
  //   "Addr": {
  //     "$class": "org.disaster.model.Address",
  //     "Country": "string",
  //     "State": "string",
  //     "District": "string",
  //     "Zip_Code": "string",
  //     "Area": "string",
  //     "Other": "string",
  //     "id": "string"
  //   },
  //   "Role":"resident",
  //   "Resident_Email": "des@gmail.com",
  //   "Contact": "746874612",
  //   "Biometric": "vBIyPO=",
  //   "BloodGroup": "O+",
  //   "shelter": []
  // }

  // this.userf= {
  //   "$class": "org.disaster.model.NGO",
  //   "GlobalId": "string",
  //   "Name": "string",
  //   "Admin": "string",
  //   "Role":"ngo",
  //   "Addr": {
  //     "$class": "org.disaster.model.Address",
  //     "Country": "string",
  //     "State": "string",
  //     "District": "string",
  //     "Zip_Code": "string",
  //     "Area": "string",
  //     "Other": "string",
  //     "id": "string"
  //   },
  //   "NGO_Email": "string",
  //   "Contact": "string",
  //   "Branches": [],
  //   "Status": true,
  //   "Blacklist": true,
  //   "ServicesProvide": [],
  //   "Active_event": [],
  //   "Past_Disaster": {
  //     "$class": "org.disaster.model.Disaster_Event",
  //     "Event_Id": "string",
  //     "EventName": "string",
  //     "Created_Date": "2018-09-15T17:08:56.974Z",
  //     "End_Date": "2018-09-15T17:08:56.974Z",
  //     "loc": {
  //       "$class": "org.disaster.model.DisLocation",
  //       "State": "string",
  //       "Country": "string",
  //       "id": "string"
  //     },
  //     "Type_Of_Disaster": "string",
  //     "AreaAffected": [],
  //     "Types_Of_Help_Needed": [],
  //     "status": true,
  //     "CreatedBy": {},
  //     "ngos": [
  //       {}
  //     ]
  //   }
  // }
  
    if(this.user.Role=='ngo'){
      this.showModal();
    }

   }

  ngOnInit() {
     
}


   showModal(){
        
     this.servicesProvide="";
     this.showbranches=false;
        
     if(this.user.ServicesProvide.length!=0){
       this.servicesProvide=this.user.ServicesProvide[0];
     }

     
     
     for(let index=1; index<this.user.ServicesProvide.length; index++){
       this.servicesProvide=this.servicesProvide+","+this.user.ServicesProvide[index];
     }

    
    
   }

}
